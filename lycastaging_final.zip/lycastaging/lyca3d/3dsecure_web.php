<!--Author: Kanchan
Date: Apr 26, 2013
This page deals with posting of data to 3d secure page -->
<html>
<head>
<script type="text/javascript">
	//Javascript function which submits the form data to 3d secure page
	function submit_data()
	{
	  //
	  document.getElementById('3d_secure_form').submit();
	}
</script>
</head>
<!--after the page load is done, calls the javascript function submit_data to post the data-->
<body onLoad="submit_data();">
	<!--Static loading message-->
	<p style="text-align:center; line-height:20px; font-weight:bold; color:#333; font-family:Arial, Helvetica, sans-serif">Loading....<br>Please wait</p>
	<!--Below form is filled with the dat coming from mobile app-->
	<form id="3d_secure_form" name="3d_secure_form" action='<?php echo urldecode($_REQUEST['action_url']); ?>' method="post">
	<P>
	<!--fetches the request parameter value and fills in paReq hidden field-->
	<input type='hidden' value='<?php echo str_replace(' ','+',urldecode($_REQUEST['pareq_value'])); ?>' name='PaReq'>
	<!--this hidden field holds the value of return url.-->
	<input type="hidden" value='http://83.137.6.12:7070/Lycamobileweb/lyca3d/checkresponse_web.php' name="TermUrl">
	<!--fetches the md value and fills in MD hidden field-->
	<input type='hidden' value='<?php echo $_REQUEST['md_value']; ?>' name='MD' > 
</body>
</html>
