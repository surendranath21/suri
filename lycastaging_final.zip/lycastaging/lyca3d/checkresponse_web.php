<?php
//Author: Kanchan
//Date: Apr 26, 2013
//if response is present, return the response back to mobile app       
	ob_start(); // clears the output the output buffer and ready to display the output
       //echo "Processing...".$_REQUEST['PaRes'];exit; 
	if(isset($_REQUEST['PaRes']))//checks if posted data to this page contains the response, if resppnse is present returns the response back to mobile app
	{
	    //header("location: 3dresponse.php?pares=".$_REQUEST['PaRes']); //redirects to response page with response data comming from pay page
	    
	    header("location: http://83.137.6.12:7070/Lycamobileweb/paymentresponse.html?pares=".$_REQUEST['PaRes']); 
	    
	}
	else 
	{
	    echo "Error processing... please try again later!";
	}
?>
