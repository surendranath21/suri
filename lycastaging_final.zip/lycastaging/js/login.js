
$(function() {
 $("#login").click(function () {
    
    var txtMobileNum = $.trim($("#UserName").val());
	/*//checking first character, if 0 replace with 44/1
	if(txtMobileNum.charAt(0) == "0")
	{
		txtMobileNum = localStorage.mobileIndex+txtMobileNum.substring(1, txtMobileNum.length);
	}*/
	
	if(localStorage.CountryCode == "USA"){
	    
		var mobiIndex = "1";
		txtMobileNum = mobiIndex.concat(txtMobileNum);
	}

	if(localStorage.CountryCode == "GBR" && txtMobileNum.charAt(0) == "0"){
	    txtMobileNum = localStorage.mobileIndex+txtMobileNum.substring(1, txtMobileNum.length);
	}
	
	var txtPwd = $.trim($("#Password").val());
	if (txtMobileNum == "") {
		alert('Please Enter Mobile Number');
		return false;
	}else if (txtMobileNum.length < 10) {
		alert("Mobile Number should be at least 10 digits");
		return false;
	} else if (txtPwd == "") {
		alert('Please Enter Password');
		return false;
	}else{
		if(document.getElementById("remember_me").checked)
		{
			var rememberme = true;
		}else{
			var rememberme = false;
		}
		var url = localStorage.portAddress+"Login";
		var post_data = '{"CountryCode":"'+localStorage.CountryCode+'","LanguageCode":"'+localStorage.LanguageCode+'","BrandCode":"'+localStorage.BrandCode+'","UserName":"'+txtMobileNum+'","Password":"'+txtPwd+'"}';
		
		ldr.show();
		$.ajax({
		type:'post',
		url: url,
		data: post_data,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			if(res.Response['ResponseCode'] == "0")
			{
				//alert(res.Response['ResponseDesc']);
				//if(res.Puk != "" ){
					localStorage.MSISDN = res.MSISDN;
					localStorage.PUK = res.Puk;
					localStorage.Title = res.Title;
					localStorage.FirstName = res.FirstName;
					localStorage.LastName = res.LastName;
					localStorage.IsAutoTopup = res.IsAutoTopup;
					
					if(rememberme == true){
						localStorage.remember = true;
						if(localStorage.CountryCode == "USA"){
						    localStorage.rememberMSISDN = txtMobileNum.substring(1,txtMobileNum.length);
						}else{
						    localStorage.rememberMSISDN = txtMobileNum;
						}
						localStorage.rememberPassword = txtPwd;
					}else{
						localStorage.remember = false;
						localStorage.removeItem('rememberMSISDN');
						localStorage.removeItem('rememberPassword');
					}
					
					window.location = 'myLycamobile.html';
				/*}else{
					alert("Invalid Mobile Number");
					return false;
				}*/
				
			}else {
				alert(res.Response['ResponseDesc']);
			}
		},
		error: function(xhr)
		{
		    ldr.hide();
			alert(xhr.statusText);
		}
	});
	}
    });
    
    //Registration
    $("#register").click(function (){
    window.location = "registration.html";
    });
    
    //Forgot Password
    $("#forgotPassword").click(function(){
    	
    	var MSISDN = $.trim($("#MSISDN").val());
	    
	if(localStorage.CountryCode == "USA"){

		var mobiIndex = "1";
		MSISDN = mobiIndex.concat(MSISDN);
	}

	if(localStorage.CountryCode == "GBR" && MSISDN.charAt(0) == "0"){
		MSISDN = localStorage.mobileIndex+MSISDN.substring(1, MSISDN.length);
	}
	    
    	var ICCID = $.trim($("#ICCID").val());
	    
	var dob = $.trim($("#DOB").val());
	var dob_arr = dob.split('/');
	var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
	    
    	/*var dob = $.trim($("#DOB").val());
    	var dob_arr = dob.split('/');
        if(localStorage.DateTimeFormat == "dd/MM/yyyy")
        {
	        var DateOfBirth = dob_arr[1]+dob_arr[0]+dob_arr[2];
        }
        if(localStorage.DateTimeFormat == "MM/dd/yyyy")
        {
	        var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
        }*/
    	
    	if(MSISDN == ""){
    		alert("Please enter Mobile Number");
    		return false;
    	}else if(MSISDN.length > 15){
    		alert("Please enter valid Mobile Number");
    		return false;
    	}
    	if(ICCID == ""){
    		alert("Please enter ICCID Number");
    		return false;
    	}
    	if(DOB == ""){
    		alert("Please enter Date of Birth");
    		return false;
    	}
    	
    	var forgotJson = '{"MSISDN" : "'+MSISDN+'","ICCID" : "'+ICCID+'","DOB" : "'+DateOfBirth+'","CountryCode" : "'+localStorage.CountryCode+'","LanguageCode" : "'+localStorage.LanguageCode+'","BrandCode" : "'+localStorage.BrandCode+'" }';
    	var forgotURL = localStorage.portAddress+"ForgotPassword";
    	ldr.show();
    	$.ajax({
    		type:'post',
    		url: forgotURL,
    		data: forgotJson,
    		async: true,
    		contentType:'application/json',
    		success:function(res)
    		{
    		    ldr.hide();
    			if(res.ResponseCode == "0") {
    				alert("Password Reset successfully");
    			}else if(res.ResponseCode == "1") {
    				alert("Password Reset successfully. But SMS Not Sent");
    			}else {
    				alert(res.ResponseDesc);
    			}
    			
    		},
    		error: function(xhr)
    		{
    		    ldr.hide();
    			//alert(xhr.statusText);
    		}
    	});
    });
});
