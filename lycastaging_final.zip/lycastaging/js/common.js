//window.localStorage.clear();
if(localStorage.CountryCode == undefined || localStorage.CountryCode == "")
{
	//localStorage.CountryCode = "GBR";
	if(document.URL.indexOf("ChangeCountry.html") == "-1"){
		window.location = "ChangeCountry.html";
	}
}

if(localStorage.CountryCode == "USA"){
	localStorage.currencySign = "$";
	localStorage.currencyPaisa = "¢";
	localStorage.mobileIndex = "1";//used o replace 0 @ mobile number starting
	
}else if(localStorage.CountryCode == "GBR"){
	localStorage.currencySign = "£";
	localStorage.currencyPaisa = "p";
	localStorage.mobileIndex = "44";//used o replace 0 @ mobile number starting
}

//Local Storage values
localStorage.LanguageCode = "en";
localStorage.BrandCode = "LYCA";
localStorage.portNumber = "http://83.137.6.12:7070";
localStorage.portAddress = localStorage.portNumber+"/MyAccountsAPI"+localStorage.CountryCode+".svc/JSON/";
localStorage.paymentAddress = "http://83.137.6.12:7070/Lycamobileweb/lyca3d/3dsecure_web.php?";
//localStorage.paymentAddress = "http://115.112.109.186/lyca3d/3dsecure_web.php?";

//facebook app id
var application_id = "461771987240665";

//To Display Settings
function showSettings(showHideDiv, switchTextDiv) {
	var ele = document.getElementById(showHideDiv);
	var text = document.getElementById(switchTextDiv);
	if(ele.style.display == "block") {
    		ele.style.display = "none";
		text.innerHTML = '<img src="img/settings.png" width="44" height="44" border="0">';
  	}
	else {
		ele.style.display = "block";
		text.innerHTML = '<img src="img/settings_color.png" width="44" height="44" border="0">';
	}
}

function gotoPage(pageName){
    if($.trim(pageName) != "")
    window.location = $.trim(pageName);
}

//checking specail characters
function isSpclChar(str,boxName){
   var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
   for (var i = 0; i < str.length; i++) {
    if (iChars.indexOf(str.charAt(i)) != -1) {
            alert ("Special characters are not allowed in "+boxName);
            return false;
        }
    }
}

$(function(){
if(document.getElementById("settings")){
    //$('body').click(function(){ showSettings('settings','settingsImg'); });
}
//checking login
if(localStorage.MSISDN == undefined || localStorage.MSISDN == "0" || localStorage.MSISDN == ""){
	$("#settingsHeader").hide();
    var curUrl = document.URL;
    if(curUrl.indexOf("myLycamobile.html") != "-1" || curUrl.indexOf("personalDetails.html") != "-1" || curUrl.indexOf("onlinetopup.html") != "-1"  || curUrl.indexOf("autotopup.html") != "-1" || curUrl.indexOf("topups.html") != "-1" || curUrl.indexOf("changepassword.html") != "-1" || curUrl.indexOf("myusage.html") != "-1")
    {
    	window.location = "login.html";
    }
}

//murali js for styles
if (window.devicePixelRatio > 1) {
	var lowresImages = $('img');
	lowresImages.each(function(i) {
		var lowres = $(this).attr('src');
		var highres = lowres.replace(".", "@2x.");
		$(this).attr('src', highres);
	});
}

/*var redirectAgent=navigator.userAgent.toLowerCase();
if(redirectAgent.indexOf("gt-i9300")>0){
	document.write("<link rel='stylesheet' href='css/s3.css'>");
}*/
//end of styles

//Clearing the session
$("#logout_btn").click(function(){
    localStorage.removeItem('MSISDN');
	localStorage.removeItem('PUK');
	localStorage.removeItem('Title');
	localStorage.removeItem('FirstName');
	localStorage.removeItem('LastName');
	localStorage.removeItem('IsAutoTopup');
	
	window.location = "login.html";
});

$("#change_country").click(function(){
	
	selected_country = $("li[class$='ui-selected']").text();
	
	if(selected_country == "" && (localStorage.CountryCode == "GBR" || localStorage.CountryCode == "USA")){
		window.location = "dashboard.html";
		return false;
	}

	if(selected_country == "")
	{
	    alert("Please select a Country");
	    return false;
	}
	
	var select_country_code = selected_country;
	
	if(select_country_code == "United States" && localStorage.CountryCode == "USA"){
		window.location = "dashboard.html";
		return false;
	}
	if(select_country_code == "United Kingdom" && localStorage.CountryCode == "GBR"){
		window.location = "dashboard.html";
		return false;
	}
	
	if(selected_country == "United States")
	{
		localStorage.CountryCode = "USA";
		localStorage.DateTimeFormat = "MM/dd/yyyy";
		
	}else{
		localStorage.CountryCode = "GBR";
		localStorage.DateTimeFormat = "dd/MM/yyyy";
	}
	
	localStorage.portAddress = localStorage.portNumber+"/MyAccountsAPI"+localStorage.CountryCode+".svc/JSON/";
	localStorage.removeItem('MSISDN');
	localStorage.removeItem('PUK');
	localStorage.removeItem('Title');
	localStorage.removeItem('FirstName');
	localStorage.removeItem('LastName');
	localStorage.removeItem('IsAutoTopup');
	localStorage.removeItem('remember');
	localStorage.removeItem('rememberMSISDN');
	localStorage.removeItem('rememberPassword');
	
	window.location = "dashboard.html";

});

	adjustFooterPosition();
});

function adjustFooterPosition(){
	$("input,select").bind("focusin focusout",function(evt){
		if(evt.type=="focusin"){
			$(".top-bottom.bottom").css("position","static");
			$(".top-bottom.bottom").css("bottom","0px");
			
			$(".top-bottom.top").css("position","absolute");
			$(".top-bottom.top").css("top","-44px");
			
		}else if(evt.type=="focusout"){
			$(".top-bottom.bottom").css("position","fixed");
			$(".top-bottom.bottom").css("bottom","0px");
			
			$(".top-bottom.top").css("position","fixed");
			$(".top-bottom.top").css("top","0px");
			
		}
	})
}

//checking whether logged in or not
function checkLogin(page){
	if(page == "more.html"){
		window.location = page;
		return false;
	}
	if(localStorage.MSISDN == undefined || localStorage.MSISDN == "0" || localStorage.MSISDN == ""){
		window.location = "login.html";
		return false;
	}
	else{
		window.location = page;
	}
}

// List of countries
if(localStorage.CountryCode == "GBR"){
var CountriesArr = [
{countryName: "Afghanistan",value: "470"},
{countryName: "Albania",value: "469"},
{countryName: "Algeria",value: "468"},
{countryName: "American Samoa",value: "467"},
{countryName: "Andorra",value: "466"},
{countryName: "Angola",value: "465"},
{countryName: "Anguilla",value: "464"},
{countryName: "Antarctica",value: "463"},
{countryName: "Antigua & Barbuda",value: "462"},
{countryName: "Argentina",value: "461"},
{countryName: "Armenia",value: "460"},
{countryName: "Aruba",value: "459"},
{countryName: "Ascension Island",value: "458"},
{countryName: "Australia",value: "457"},
{countryName: "Austria",value: "456"},
{countryName: "Azerbaijan",value: "455"},
{countryName: "Bahamas",value: "454"},
{countryName: "Bahrain",value: "453"},
{countryName: "Bangladesh",value: "452"},
{countryName: "Barbados",value: "451"},
{countryName: "Belarus",value: "450"},
{countryName: "Belgium",value: "449"},
{countryName: "Belize",value: "448"},
{countryName: "Benin",value: "447"},
{countryName: "Bermuda",value: "446"},
{countryName: "Bhutan",value: "445"},
{countryName: "Bolivia",value: "444"},
{countryName: "Bolivia Cochabamba",value: "477"},
{countryName: "Bolivia Lapaz",value: "484"},
{countryName: "Bolivia Santa Cruz",value: "483"},
{countryName: "Bosnia and Herzegovina",value: "443"},
{countryName: "Botswana",value: "442"},
{countryName: "Brazil",value: "441"},
{countryName: "Brazil Rio de Janeiro",value: "482"},
{countryName: "Brazil Sao Paulo",value: "481"},
{countryName: "British Virgin Islands",value: "440"},
{countryName: "Brunei Darussalam",value: "439"},
{countryName: "Bulgaria",value: "438"},
{countryName: "Burkina Faso",value: "437"},
{countryName: "Burundi",value: "436"},
{countryName: "Cambodia",value: "435"},
{countryName: "Cameroon",value: "434"},
{countryName: "Canada",value: "433"},
{countryName: "Cape Verde",value: "432"},
{countryName: "Cayman Islands",value: "431"},
{countryName: "Central African Republic",value: "430"},
{countryName: "Chad",value: "429"},
{countryName: "Chatham Islands",value: "428"},
{countryName: "Chile",value: "427"},
{countryName: "China",value: "426"},
{countryName: "Christmas Island",value: "498"},
{countryName: "Cocos Island",value: "500"},
{countryName: "Colombia",value: "425"},
{countryName: "Colombia Bogota",value: "480"},
{countryName: "Colombia Cali",value: "492"},
{countryName: "Comoros",value: "424"},
{countryName: "Congo",value: "423"},
{countryName: "Cook Islands",value: "422"},
{countryName: "Costa Rica",value: "421"},
{countryName: "Croatia",value: "419"},
{countryName: "Cuba",value: "418"},
{countryName: "Cyprus Greek",value: "417"},
{countryName: "Cyprus North",value: "416"},
{countryName: "Czech Republic",value: "415"},
{countryName: "Dem.Rep.of Congo (Zaire)",value: "414"},
{countryName: "Denmark",value: "413"},
{countryName: "Diego Garcia",value: "412"},
{countryName: "Djibouti",value: "411"},
{countryName: "Dominica",value: "410"},
{countryName: "Dominican Republic",value: "409"},
{countryName: "East Timor",value: "408"},
{countryName: "Easter Island",value: "502"},
{countryName: "Ecuador",value: "407"},
{countryName: "Egypt",value: "406"},
{countryName: "El Salvador",value: "405"},
{countryName: "Equatorial Guinea",value: "404"},
{countryName: "Eritrea",value: "403"},
{countryName: "Estonia",value: "402"},
{countryName: "Ethiopia",value: "401"},
{countryName: "Falkland Islands",value: "400"},
{countryName: "Faroe Islands",value: "399"},
{countryName: "Fiji",value: "398"},
{countryName: "Finland",value: "397"},
{countryName: "France",value: "396"},
{countryName: "French Guiana",value: "395"},
{countryName: "French Polynesia",value: "394"},
{countryName: "Gabon",value: "393"},
{countryName: "Gambia",value: "392"},
{countryName: "Georgia",value: "391"},
{countryName: "Germany",value: "390"},
{countryName: "Ghana",value: "389"},
{countryName: "Gibraltar",value: "388"},
{countryName: "Greece",value: "387"},
{countryName: "Greenland",value: "386"},
{countryName: "Grenada",value: "385"},
{countryName: "Guadeloupe",value: "384"},
{countryName: "Guam",value: "383"},
{countryName: "Guatemala",value: "382"},
{countryName: "Guinea",value: "381"},
{countryName: "Guinea-Bissau",value: "380"},
{countryName: "Guyana",value: "379"},
{countryName: "Haiti",value: "378"},
{countryName: "Honduras",value: "377"},
{countryName: "Hong Kong",value: "376"},
{countryName: "Hungary",value: "375"},
{countryName: "Iceland",value: "374"},
{countryName: "India",value: "373"},
{countryName: "Indonesia",value: "372"},
{countryName: "Indonesia Jakarta",value: "491"},
{countryName: "Iran",value: "371"},
{countryName: "Iraq",value: "370"},
{countryName: "Ireland",value: "369"},
{countryName: "Israel",value: "368"},
{countryName: "Italy",value: "367"},
{countryName: "Ivory Coast",value: "420"},
{countryName: "Jamaica",value: "366"},
{countryName: "Japan",value: "365"},
{countryName: "Jordan",value: "364"},
{countryName: "Kazakhstan",value: "363"},
{countryName: "Kenya",value: "362"},
{countryName: "Kiribati",value: "361"},
{countryName: "Korea North",value: "360"},
{countryName: "Korea South",value: "359"},
{countryName: "Kosova",value: "358"},
{countryName: "Kuwait",value: "357"},
{countryName: "Kyrgyzstan",value: "356"},
{countryName: "Laos",value: "355"},
{countryName: "Latvia",value: "354"},
{countryName: "Lebanon",value: "353"},
{countryName: "Lesotho",value: "352"},
{countryName: "Liberia",value: "351"},
{countryName: "Libya",value: "350"},
{countryName: "Liechtenstein",value: "349"},
{countryName: "Lithuania",value: "348"},
{countryName: "Luxembourg",value: "347"},
{countryName: "Macau",value: "346"},
{countryName: "Macedonia",value: "345"},
{countryName: "Madagascar",value: "344"},
{countryName: "Malawi",value: "343"},
{countryName: "Malaysia",value: "342"},
{countryName: "Maldives",value: "341"},
{countryName: "Mali",value: "340"},
{countryName: "Malta",value: "339"},
{countryName: "Mariana Islands",value: "338"},
{countryName: "Marshall Islands",value: "337"},
{countryName: "Martinique",value: "336"},
{countryName: "Mauritania",value: "335"},
{countryName: "Mauritius",value: "334"},
{countryName: "Mayotte Islands",value: "333"},
{countryName: "Mexico",value: "332"},
{countryName: "Micronesia",value: "331"},
{countryName: "Moldova",value: "330"},
{countryName: "Monaco",value: "329"},
{countryName: "Mongolia",value: "328"},
{countryName: "Montenegro",value: "327"},
{countryName: "Montserrat",value: "326"},
{countryName: "Morocco",value: "325"},
{countryName: "Morocco wana",value: "324"},
{countryName: "Mozambique",value: "323"},
{countryName: "Myanmar",value: "322"},
{countryName: "Namibia",value: "321"},
{countryName: "Nauru",value: "320"},
{countryName: "Nepal",value: "319"},
{countryName: "Netherlands",value: "318"},
{countryName: "Netherlands Antilles",value: "317"},
{countryName: "New Caledonia",value: "316"},
{countryName: "New Zealand",value: "315"},
{countryName: "Nicaragua",value: "314"},
{countryName: "Niger",value: "313"},
{countryName: "Nigeria",value: "312"},
{countryName: "Niue",value: "311"},
{countryName: "Norfolk Islands",value: "310"},
{countryName: "North Yemen",value: "309"},
{countryName: "Norway",value: "308"},
{countryName: "Oman",value: "307"},
{countryName: "Pakistan",value: "306"},
{countryName: "Palau",value: "305"},
{countryName: "Palestine",value: "304"},
{countryName: "Panama",value: "303"},
{countryName: "Papua New Guinea",value: "302"},
{countryName: "Paraguay",value: "301"},
{countryName: "Peru",value: "300"},
{countryName: "Philippines",value: "299"},
{countryName: "Poland",value: "298"},
{countryName: "Portugal",value: "297"},
{countryName: "Puerto Rico",value: "296"},
{countryName: "Qatar",value: "295"},
{countryName: "Reunion Island",value: "294"},
{countryName: "Romania",value: "293"},
{countryName: "Russia",value: "292"},
{countryName: "Russia Moscow",value: "490"},
{countryName: "Russia St. Petersburg",value: "489"},
{countryName: "Rwanda",value: "291"},
{countryName: "San Marino",value: "290"},
{countryName: "Sao Tome & Principe",value: "289"},
{countryName: "Saudi Arabia",value: "288"},
{countryName: "Senegal",value: "287"},
{countryName: "Serbia",value: "286"},
{countryName: "Seychelles",value: "285"},
{countryName: "Sierra Leone",value: "284"},
{countryName: "Singapore",value: "283"},
{countryName: "Slovakia",value: "282"},
{countryName: "Slovenia",value: "281"},
{countryName: "Solomon Islands",value: "280"},
{countryName: "Somalia",value: "279"},
{countryName: "South Africa",value: "278"},
{countryName: "Spain",value: "277"},
{countryName: "Sri Lanka",value: "276"},
{countryName: "St. Kitts and Nevis",value: "275"},
{countryName: "St. Lucia",value: "274"},
{countryName: "St. Vincent and Grenadines",value: "273"},
{countryName: "St.Helena",value: "272"},
{countryName: "St.Pierre & Miquelon",value: "271"},
{countryName: "Sudan",value: "270"},
{countryName: "Suriname",value: "269"},
{countryName: "Swaziland",value: "268"},
{countryName: "Sweden",value: "267"},
{countryName: "Switzerland",value: "266"},
{countryName: "Syria",value: "265"},
{countryName: "Taiwan",value: "264"},
{countryName: "Tajikistan",value: "263"},
{countryName: "Tanzania",value: "262"},
{countryName: "Thailand",value: "261"},
{countryName: "Togo",value: "260"},
{countryName: "Tokelau",value: "259"},
{countryName: "Tonga",value: "258"},
{countryName: "Trinidad and Tobago",value: "257"},
{countryName: "Tunisia",value: "256"},
{countryName: "Turkey",value: "255"},
{countryName: "Turkmenistan",value: "254"},
{countryName: "Turks & Caicos Islands",value: "253"},
{countryName: "Tuvalu",value: "252"},
{countryName: "Uganda",value: "251"},
{countryName: "Ukraine",value: "250"},
{countryName: "United Arab Emirates",value: "249"},
{countryName: "United States",value: "247"},
{countryName: "Uruguay",value: "246"},
{countryName: "US Virgin Island",value: "496"},
{countryName: "Uzbekistan",value: "245"},
{countryName: "Vanuatu",value: "244"},
{countryName: "Vatican City",value: "243"},
{countryName: "Venezuela",value: "242"},
{countryName: "Vietnam",value: "241"},
{countryName: "Wallis & Funtuna Island",value: "240"},
{countryName: "Western Samoa",value: "239"},
{countryName: "Yemen",value: "238"},
{countryName: "Zambia",value: "237"},
{countryName: "Zimbabwe",value: "236"}];
}
else{
var CountriesArr = [
    {value: "470",countryName: "Afghanistan"},
	{value: "469",countryName: "Albania"},
	{value: "468",countryName: "Algeria"},
	{value: "467",countryName: "American Samoa"},
	{value: "466",countryName: "Andorra"},
	{value: "465",countryName: "Angola"},
	{value: "464",countryName: "Anguilla"},
	{value: "463",countryName: "Antarctica"},
	{value: "462",countryName: "Antigua & Barbuda"},
	{value: "461",countryName: "Argentina"},
	{value: "460",countryName: "Armenia"},
	{value: "459",countryName: "Aruba"},
	{value: "458",countryName: "Ascension Island"},
	{value: "457",countryName: "Australia"},
	{value: "456",countryName: "Austria"},
	{value: "455",countryName: "Azerbaijan"},
	{value: "454",countryName: "Bahamas"},
	{value: "453",countryName: "Bahrain"},
	{value: "452",countryName: "Bangladesh"},
	{value: "451",countryName: "Barbados"},
	{value: "450",countryName: "Belarus"},
	{value: "449",countryName: "Belgium"},
	{value: "448",countryName: "Belize"},
	{value: "447",countryName: "Benin"},
	{value: "446",countryName: "Bermuda"},
	{value: "445",countryName: "Bhutan"},
	{value: "444",countryName: "Bolivia"},
	{value: "477",countryName: "Bolivia Cochabamba"},
	{value: "484",countryName: "Bolivia Lapaz"},
	{value: "483",countryName: "Bolivia Santa Cruz"},
	{value: "443",countryName: "Bosnia and Herzegovina"},
	{value: "442",countryName: "Botswana"},
	{value: "441",countryName: "Brazil"},
	{value: "482",countryName: "Brazil Rio de Janeiro"},
	{value: "481",countryName: "Brazil Sao Paulo"},
	{value: "440",countryName: "British Virgin Islands"},
	{value: "439",countryName: "Brunei Darussalam"},
	{value: "438",countryName: "Bulgaria"},
	{value: "437",countryName: "Burkina Faso"},
	{value: "436",countryName: "Burundi"},
	{value: "435",countryName: "Cambodia"},
	{value: "434",countryName: "Cameroon"},
	{value: "433",countryName: "Canada"},
	{value: "432",countryName: "Cape Verde"},
	{value: "431",countryName: "Cayman Islands"},
	{value: "430",countryName: "Central African Republic"},
	{value: "429",countryName: "Chad"},
	{value: "428",countryName: "Chatham Islands"},
	{value: "427",countryName: "Chile"},
	{value: "426",countryName: "China"},
	{value: "494",countryName: "Christmas Island"},
	{value: "496",countryName: "Cocos Island"},
	{value: "425",countryName: "Colombia"},
	{value: "480",countryName: "Colombia Bogota"},
	{value: "492",countryName: "Colombia Cali"},
	{value: "424",countryName: "Comoros"},
	{value: "423",countryName: "Congo"},
	{value: "422",countryName: "Cook Islands"},
	{value: "421",countryName: "Costa Rica"},
	{value: "419",countryName: "Croatia"},
	{value: "418",countryName: "Cuba"},
	{value: "417",countryName: "Cyprus Greek"},
	{value: "416",countryName: "Cyprus North"},
	{value: "415",countryName: "Czech Republic"},
	{value: "414",countryName: "Dem.Rep.of Congo (Zaire)"},
	{value: "413",countryName: "Denmark"},
	{value: "412",countryName: "Diego Garcia"},
	{value: "411",countryName: "Djibouti"},
	{value: "410",countryName: "Dominica"},
	{value: "409",countryName: "Dominican Republic"},
	{value: "408",countryName: "East Timor"},
	{value: "498",countryName: "Easter Island"},
	{value: "407",countryName: "Ecuador"},
	{value: "406",countryName: "Egypt"},
	{value: "405",countryName: "El Salvador"},
	{value: "404",countryName: "Equatorial Guinea"},
	{value: "403",countryName: "Eritrea"},
	{value: "402",countryName: "Estonia"},
	{value: "401",countryName: "Ethiopia"},
	{value: "400",countryName: "Falkland Islands"},
	{value: "399",countryName: "Faroe Islands"},
	{value: "398",countryName: "Fiji"},
	{value: "397",countryName: "Finland"},
	{value: "396",countryName: "France"},
	{value: "395",countryName: "French Guiana"},
	{value: "394",countryName: "French Polynesia"},
	{value: "393",countryName: "Gabon"},
	{value: "392",countryName: "Gambia"},
	{value: "391",countryName: "Georgia"},
	{value: "390",countryName: "Germany"},
	{value: "389",countryName: "Ghana"},
	{value: "388",countryName: "Gibraltar"},
	{value: "387",countryName: "Greece"},
	{value: "386",countryName: "Greenland"},
	{value: "385",countryName: "Grenada"},
	{value: "384",countryName: "Guadeloupe"},
	{value: "383",countryName: "Guam"},
	{value: "382",countryName: "Guatemala"},
	{value: "381",countryName: "Guinea"},
	{value: "380",countryName: "Guinea-Bissau"},
	{value: "379",countryName: "Guyana"},
	{value: "378",countryName: "Haiti"},
	{value: "377",countryName: "Honduras"},
	{value: "376",countryName: "Hong Kong"},
	{value: "375",countryName: "Hungary"},
	{value: "374",countryName: "Iceland"},
	{value: "373",countryName: "India"},
	{value: "372",countryName: "Indonesia"},
	{value: "491",countryName: "Indonesia Jakarta"},
	{value: "371",countryName: "Iran"},
	{value: "370",countryName: "Iraq"},
	{value: "369",countryName: "Ireland"},
	{value: "368",countryName: "Israel"},
	{value: "367",countryName: "Italy"},
	{value: "420",countryName: "Ivory Coast"},
	{value: "366",countryName: "Jamaica"},
	{value: "365",countryName: "Japan"},
	{value: "364",countryName: "Jordan"},
	{value: "363",countryName: "Kazakhstan"},
	{value: "362",countryName: "Kenya"},
	{value: "361",countryName: "Kiribati"},
	{value: "360",countryName: "Korea North"},
	{value: "359",countryName: "Korea South"},
	{value: "358",countryName: "Kosova"},
	{value: "357",countryName: "Kuwait"},
	{value: "356",countryName: "Kyrgyzstan"},
	{value: "355",countryName: "Laos"},
	{value: "354",countryName: "Latvia"},
	{value: "353",countryName: "Lebanon"},
	{value: "352",countryName: "Lesotho"},
	{value: "351",countryName: "Liberia"},
	{value: "350",countryName: "Libya"},
	{value: "349",countryName: "Liechtenstein"},
	{value: "348",countryName: "Lithuania"},
	{value: "347",countryName: "Luxembourg"},
	{value: "346",countryName: "Macau"},
	{value: "345",countryName: "Macedonia"},
	{value: "344",countryName: "Madagascar"},
	{value: "343",countryName: "Malawi"},
	{value: "342",countryName: "Malaysia"},
	{value: "341",countryName: "Maldives"},
	{value: "340",countryName: "Mali"},
	{value: "339",countryName: "Malta"},
	{value: "338",countryName: "Mariana Islands"},
	{value: "337",countryName: "Marshall Islands"},
	{value: "336",countryName: "Martinique"},
	{value: "335",countryName: "Mauritania"},
	{value: "334",countryName: "Mauritius"},
	{value: "333",countryName: "Mayotte Islands"},
	{value: "332",countryName: "Mexico"},
	{value: "331",countryName: "Micronesia"},
	{value: "330",countryName: "Moldova"},
	{value: "329",countryName: "Monaco"},
	{value: "328",countryName: "Mongolia"},
	{value: "327",countryName: "Montenegro"},
	{value: "326",countryName: "Montserrat"},
	{value: "325",countryName: "Morocco"},
	{value: "324",countryName: "Morocco wana"},
	{value: "323",countryName: "Mozambique"},
	{value: "322",countryName: "Myanmar"},
	{value: "321",countryName: "Namibia"},
	{value: "320",countryName: "Nauru"},
	{value: "319",countryName: "Nepal"},
	{value: "318",countryName: "Netherlands"},
	{value: "317",countryName: "Netherlands Antilles"},
	{value: "316",countryName: "New Caledonia"},
	{value: "315",countryName: "New Zealand"},
	{value: "314",countryName: "Nicaragua"},
	{value: "313",countryName: "Niger"},
	{value: "312",countryName: "Nigeria"},
	{value: "311",countryName: "Niue"},
	{value: "310",countryName: "Norfolk Islands"},
	{value: "308",countryName: "Norway"},
	{value: "307",countryName: "Oman"},
	{value: "306",countryName: "Pakistan"},
	{value: "305",countryName: "Palau"},
	{value: "304",countryName: "Palestine"},
	{value: "303",countryName: "Panama"},
	{value: "302",countryName: "Papua New Guinea"},
	{value: "301",countryName: "Paraguay"},
	{value: "300",countryName: "Peru"},
	{value: "299",countryName: "Philippines"},
	{value: "298",countryName: "Poland"},
	{value: "297",countryName: "Portugal"},
	{value: "296",countryName: "Puerto Rico"},
	{value: "295",countryName: "Qatar"},
	{value: "294",countryName: "Reunion Island"},
	{value: "293",countryName: "Romania"},
	{value: "292",countryName: "Russia"},
	{value: "490",countryName: "Russia Moscow"},
	{value: "489",countryName: "Russia St. Petersburg"},
	{value: "291",countryName: "Rwanda"},
	{value: "290",countryName: "San Marino"},
	{value: "289",countryName: "Sao Tome & Principe"},
	{value: "288",countryName: "Saudi Arabia"},
	{value: "287",countryName: "Senegal"},
	{value: "286",countryName: "Serbia"},
	{value: "285",countryName: "Seychelles"},
	{value: "284",countryName: "Sierra Leone"},
	{value: "283",countryName: "Singapore"},
	{value: "282",countryName: "Slovakia"},
	{value: "281",countryName: "Slovenia"},
	{value: "280",countryName: "Solomon Islands"},
	{value: "279",countryName: "Somalia"},
	{value: "278",countryName: "South Africa"},
	{value: "238",countryName: "South Yemen"},
	{value: "277",countryName: "Spain"},
	{value: "276",countryName: "Sri Lanka"},
	{value: "275",countryName: "St. Kitts and Nevis"},
	{value: "274",countryName: "St. Lucia"},
	{value: "273",countryName: "St. Vincent and Grenadines"},
	{value: "272",countryName: "St.Helena"},
	{value: "271",countryName: "St.Pierre & Miquelon"},
	{value: "270",countryName: "Sudan"},
	{value: "269",countryName: "Suriname"},
	{value: "268",countryName: "Swaziland"},
	{value: "267",countryName: "Sweden"},
	{value: "266",countryName: "Switzerland"},
	{value: "265",countryName: "Syria"},
	{value: "264",countryName: "Taiwan"},
	{value: "263",countryName: "Tajikistan"},
	{value: "262",countryName: "Tanzania"},
	{value: "261",countryName: "Thailand"},
	{value: "260",countryName: "Togo"},
	{value: "259",countryName: "Tokelau"},
	{value: "258",countryName: "Tonga"},
	{value: "257",countryName: "Trinidad and Tobago"},
	{value: "256",countryName: "Tunisia"},
	{value: "255",countryName: "Turkey"},
	{value: "254",countryName: "Turkmenistan"},
	{value: "253",countryName: "Turks & Caicos Islands"},
	{value: "252",countryName: "Tuvalu"},
	{value: "251",countryName: "Uganda"},
	{value: "250",countryName: "Ukraine"},
	{value: "249",countryName: "United Arab Emirates"},
	{value: "248",countryName: "United Kingdom"},
	{value: "246",countryName: "Uruguay"},
	{value: "501",countryName: "US Virgin Island"},
	{value: "245",countryName: "Uzbekistan"},
	{value: "244",countryName: "Vanuatu"},
	{value: "243",countryName: "Vatican City"},
	{value: "242",countryName: "Venezuela"},
	{value: "241",countryName: "Vietnam"},
	{value: "240",countryName: "Wallis & Funtuna Island"},
	{value: "239",countryName: "Western Samoa"},
	{value: "309",countryName: "Yemen"},
	{value: "237",countryName: "Zambia"},
	{value: "236",countryName: "Zimbabwe"}];

}
//States Array
var us_states = [{"value" : "AL","state" : "ALABAMA"},
	{"value" : "AK","state" : "ALASKA"},
	{"value" : "AS","state" : "AMERICAN SAMOA"},
	{"value" : "AZ","state" : "ARIZONA"},
	{"value" : "AR","state" : "ARKANSAS"},
	{"value" : "CA","state" : "CALIFORNIA"}, 
	{"value" : "CO","state" : "COLORADO"}, 
	{"value" : "CT","state" : "CONNECTICUT"}, 
	{"value" : "DE","state" : "DELAWARE"}, 
	{"value" : "DC","state" : "DISTRICT OF COLUMBIA"}, 
	{"value" : "FM","state" : "FEDERATED STATES OF MICRONESIA"}, 
	{"value" : "FL","state" : "FLORIDA"}, 
	{"value" : "GA","state" : "GEORGIA"}, 
	{"value" : "GU","state" : "GUAM GU"}, 
	{"value" : "HI","state" : "HAWAII"}, 
	{"value" : "ID","state" : "IDAHO"}, 
	{"value" : "IL","state" : "ILLINOIS"}, 
	{"value" : "IN","state" : "INDIANA"}, 
	{"value" : "IA","state" : "IOWA"}, 
	{"value" : "KS","state" : "KANSAS"}, 
	{"value" : "KY","state" : "KENTUCKY"}, 
	{"value" : "LA","state" : "LOUISIANA"}, 
	{"value" : "ME","state" : "MAINE"}, 
	{"value" : "MH","state" : "MARSHALL ISLANDS"}, 
	{"value" : "MD","state" : "MARYLAND"}, 
	{"value" : "MA","state" : "MASSACHUSETTS"}, 
	{"value" : "MI","state" : "MICHIGAN"}, 
	{"value" : "MN","state" : "MINNESOTA"}, 
	{"value" : "MS","state" : "MISSISSIPPI"}, 
	{"value" : "MO","state" : "MISSOURI"}, 
	{"value" : "MT","state" : "MONTANA"}, 
	{"value" : "NE","state" : "NEBRASKA"}, 
	{"value" : "NV","state" : "NEVADA"}, 
	{"value" : "NH","state" : "NEW HAMPSHIRE"}, 
	{"value" : "NJ","state" : "NEW JERSEY"}, 
	{"value" : "NM","state" : "NEW MEXICO"}, 
	{"value" : "NY","state" : "NEW YORK"}, 
	{"value" : "NC","state" : "NORTH CAROLINA"}, 
	{"value" : "ND","state" : "NORTH DAKOTA"}, 
	{"value" : "MP","state" : "NORTHERN MARIANA ISLANDS"}, 
	{"value" : "OH","state" : "OHIO"}, 
	{"value" : "OK","state" : "OKLAHOMA"}, 
	{"value" : "OR","state" : "OREGON"}, 
	{"value" : "PW","state" : "PALAU"}, 
	{"value" : "PA","state" : "PENNSYLVANIA"}, 
	{"value" : "PR","state" : "PUERTO RICO"}, 
	{"value" : "RI","state" : "RHODE ISLAND"}, 
	{"value" : "SC","state" : "SOUTH CAROLINA"}, 
	{"value" : "SD","state" : "SOUTH DAKOTA"}, 
	{"value" : "TN","state" : "TENNESSEE"}, 
	{"value" : "TX","state" : "TEXAS"}, 
	{"value" : "UT","state" : "UTAH"}, 
	{"value" : "VT","state" : "VERMONT"}, 
	{"value" : "VI","state" : "VIRGIN ISLANDS"}, 
	{"value" : "VA","state" : "VIRGINIA"}, 
	{"value" : "WA","state" : "WASHINGTON"}, 
	{"value" : "WV","state" : "WEST VIRGINIA"}, 
	{"value" : "WI","state" : "WISCONSIN"}, 
	{"value" : "WY","state" : "WYOMING"}];

