var emailpattern = /^([A-Za-z0-9_\-\.\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~\+])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;  //ex:-someone.me@mail.com

function quickTopup() {

	var MSISDN = $("MSISDN").val();
	var TopUpAmount = $("#TopUpAmount").val();
	var Email = $("Email").val();
	var Countrycode = $("Countrycode").val();
	var CardType = $("CardType").val();
	var NameOnCard = $("NameOnCard").val();
	var CardNo = $("CardNo").val();
	var IssueDate = $("IssueDate").val();
	var ExpiryDate = $("ExpiryDate").val();
	var IssueNo = $("IssueNo").val();
	var CVV = $("CVV").val();
	var PostCode = $("PostCode").val();
	var Street = $("Street").val();
	var City = $("City").val();
	var Country = $("Country").val();
	var HouseNo = $("HouseNo").val();
	var LanguageCode = $("LanguageCode").val();
	var BrandCode = $("BrandCode").val();
	var CardId = $("CardId").val();
	var County = $("County").val();

	if(MSISDN=='') {
		 alert('Please Enter MSISDN.');
		 return false;
	} else if(MSISDN.length>15) {
		 alert('Please Enter MSISDN below 15 characters.');
		 return false;
	}
	
	if(TopUpAmount=="") {
		alert('Please Enter TopUpAmount.');
		return false;
	} else if(TopUpAmount.length>2){
		alert('Please Enter valid TopUpAmount.');
		return false;
	}
	
	if(Email=="") {
		alert('Please Enter Email.');
		return false;
	} else if(Email.length>50){
		alert('Please Enter Email Address Upto 50 characters.');
		return false;
	} else if(!Email.match(emailpattern)){
		alert('Please Enter valid Email.');
		return false;
	}
	
	if(Countrycode=="") {
		alert('Please Enter Countrycode.');
		return false;
	} else if(Countrycode.length>3){
		alert('Please Enter valid Countrycode.');
		return false;
	}
	
	if(CardType=="") {
		alert('Please Enter CardType.');
		return false;
	} else if(CardType.length>50){
		alert('Please Enter valid CardType.');
		return false;
	}
	
	if(NameOnCard=="") {
		alert('Please Enter NameOnCard.');
		return false;
	} else if(NameOnCard.length>50){
		alert('Please Enter valid NameOnCard.');
		return false;
	}
	
	if(CardNo =="") {
		alert('Please Enter CardNo.');
		return false;
	} else if(CardNo.length>15 || isNaN(CardNo)){
		alert('Please Enter valid CardNo.');
		return false;
	}
	/* 
	if(IssueDate =="") {
		alert('Please Enter IssueDate.');
		return false;
	} else if(IssueDate.length>30){
		alert('Please Enter valid IssueDate.');
		return false;
	}*/
	
	if(ExpiryDate =="") {
		alert('Please Enter ExpiryDate.');
		return false;
	} else if(ExpiryDate.length>30){
		alert('Please Enter valid ExpiryDate.');
		return false;
	}
	
	if(IssueNo !="") {
		
		if(IssueNo.length>15) {
			alert('Please Enter valid IssueNo.');
			return false;
		}
		
	} 
	
	 
	if(CVV =="") {
		alert('Please Enter CVV.');
		return false;
	} else if(CVV.length>3){
		alert('Please Enter valid CVV.');
		return false;
	}

	  
	if(PostCode =="") {
		alert('Please Enter PostCode.');
		return false;
	} else if(PostCode.length>10){
		alert('Please Enter valid PostCode.');
		return false;
	}
	
	 
	if(Street =="") {
		alert('Please Enter Street.');
		return false;
	} else if(Street.length>50){
		alert('Please Enter valid Street.');
		return false;
	}
	
	if(City =="") {
		alert('Please Enter City.');
		return false;
	} else if(City.length>50){
		alert('Please Enter valid City.');
		return false;
	}
	
	if(HouseNo =="") {
		alert('Please Enter HouseNo.');
		return false;
	} else if(HouseNo.length>10 || isNaN(HouseNo)){
		alert('Please Enter valid HouseNo.');
		return false;
	}
	
	if(LanguageCode =="") {
		alert('Please Enter LanguageCode.');
		return false;
	} else if(LanguageCode.length>5){
		alert('Please Enter valid LanguageCode.');
		return false;
	}
	
	if(BrandCode =="") {
		alert('Please Enter BrandCode.');
		return false;
	} else if(BrandCode.length>20){
		alert('Please Enter valid BrandCode.');
		return false;
	}
	
	if(CardId =="") {
		alert('Please Enter CardId.');
		return false;
	} else if(CardId.length>6 || isNaN(CardId)) {
		alert('Please Enter valid CardId.');
		return false;
	} 
	
	if(County =="") {
		alert('Please Enter County.');
		return false;
	} else if(County.length>50){
		alert('Please Enter valid County.');
		return false;
	}
}