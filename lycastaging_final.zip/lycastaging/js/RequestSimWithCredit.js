var emailpattern = /^([A-Za-z0-9_\-\.\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~\+])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
$(function(){

$("#requestSimWithTopup").click(function(){
    var Title = $.trim($("#Title").val());
    var FirstName = $.trim($("#FirstName").val());
    var LastName = $.trim($("#LastName").val());
	
    var dob = $("#DateOfBirth").val();
    var dob_arr = dob.split('/');
    var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
	
    /*var dob = $("#DateOfBirth").val();//mmddyyyy
    var dob_arr = dob.split('/');
    if(localStorage.DateTimeFormat == "dd/MM/yyyy")
    {
    	var DateOfBirth = dob_arr[1]+dob_arr[0]+dob_arr[2];
    }
    if(localStorage.DateTimeFormat == "MM/dd/yyyy")
    {
    	var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
    }*/
    var Language = $.trim($("#Language").val());
    var Promocode = $.trim($("#Promocode").val());
    var Nationality = $.trim($("#Nationality").val());
    var EmailAddress = $.trim($("#EmailAddress").val());
    var cEmailAddress = $.trim($("#cEmailAddress").val());
    var ContactNumber = $.trim($("#ContactNumber").val());
    var HearAboutUs = $.trim($("#HearAboutUs").val());
    var CallMostCountry = $.trim($("#CallMostCountry").val());
    var HouseNo = $.trim($("#HouseNo").val());
    var County = $.trim($("#County").val());
    var Street = $.trim($("#Street").val());
    var City = $.trim($("#City").val());
    var PostCode = $.trim($("#PostCode").val());
    
    var CardType = $.trim($("#CardType").val());
	var NameOnCard = $.trim($("#NameOnCard").val());
	var CardNo = $.trim($("#CardNo").val());
	var IssueDateMonth = $.trim($("#IssueDateMonth").val());
	var IssueDateMonth = $.trim($("#IssueDateYear").val());
	var ExpiryDateMonth = $.trim($("#ExpiryDateMonth").val());
	var ExpiryDateYear = $.trim($("#ExpiryDateYear").val());
	var IssueNo = $.trim($("#IssueNo").val());
	var CVV = $.trim($("#CVV").val());
    
    var Paymentamount = $.trim($("#Paymentamount").val()); 
    var TopupAmount = $.trim($("#TopupAmount").val());
    var SimType = $.trim($("#SimType").val());
    var NoofSim = $.trim($("#NoofSim").val());
    
    var BillingHouseNo = $.trim($("#BillingHouseNo").val());
    var BillingCounty = $.trim($("#BillingCounty").val());
    var BillingStreet = $.trim($("#BillingStreet").val());
    var BillingCity = $.trim($("#BillingCity").val());
    var BillingPostCode = $.trim($("#BillingPostCode").val());
    
	 if(Title == "") {
		alert("Please Select Title");
		return false;
	}

    if(FirstName == "") {
		alert("Please Enter First Name");
		return false;
	}

    if(LastName == "") {
		alert("Please Enter Last Name");
		return false;
	}

    if(DateOfBirth == "") {
		alert("Please Select Date Of Birth");
		return false;
	}

    if(EmailAddress == "") {
		alert("Please Enter Email Address");
		return false;
	}
    if(!EmailAddress.match(emailpattern)) {
		alert("Please Enter Valid Email Address");
		return false;
	}
	
	if(cEmailAddress == "") {
		alert("Please Enter Confirm Email Address");
		return false;
	}
    if(!cEmailAddress.match(emailpattern)) {
		alert("Please Enter Valid Confirm Email Address");
		return false;
	}
	if(cEmailAddress != EmailAddress)
	{
	    alert("Confirm Email Address and Email Address not match");
		return false;
	}
	
    if(Nationality == "") {
		alert("Please Enter Nationality");
		return false;
	}
	
    if(ContactNumber == "") {
		alert("Please Enter Contact Number");
		return false;
	}

    if(HouseNo == "") {
		alert("Please Enter House No.");
		return false;
	}

    if(Street == "") {
		alert("Please Enter Street");
		return false;
	}

	if(County.length>50){
		if(localStorage.CountryCode == "USA"){
			alert('State sholud be below 50 Char.');
		}else{
			alert('County sholud be below 50 Char.');
		}
		return false;
	}
	
    if(City == "") {
		alert("Please Enter City");
		return false;
	}

    if(PostCode == "") {
        if(localStorage.CountryCode == "USA"){
			alert("Please Enter Zip Code");
		}else{
			alert("Please Enter PostCode");
		}
		return false;
	}else if(PostCode.length>10 ){
		
		if(localStorage.CountryCode == "USA"){
			alert("Please Enter valid Zip Code");
		}else{
			alert('Please Enter valid PostCode');
		}
		return false;
	}

	if(localStorage.CountryCode == "USA")
		var spclCharVal = isSpclChar(PostCode,"ZipCode");
	else
		var spclCharVal = isSpclChar(PostCode,"PostCode");
	
	if(spclCharVal == false){
		return false;
	}
	
    if(HearAboutUs == "") {
		alert("Please Select How did you hear aboutus");
		return false;
	}

    if(CallMostCountry == "") {
		alert("Please Select Country you call mostly");
		return false;
	}
	
    if(Language == "") {
		alert("Please Select Language");
		return false;
	}
	
    /*if(Promocode == "") {
		alert("Please Enter Promocode");
		return false;
	}*/
	
	if(CardType=="") {
		alert('Please Select CardType');
		return false;
	} else if(CardType.length>50){
		alert('Please Enter valid CardType');
		return false;
	}
	
	if(NameOnCard=="") {
		alert('Please Enter NameOnCard');
		return false;
	} else if(NameOnCard.length>50){
		alert('Please Enter valid NameOnCard');
		return false;
	}
	
	if(CardNo =="") {
		alert('Please Enter Card Number');
		return false;
	} else if(CardNo.length>16 || isNaN(CardNo)){
		alert('Please Enter valid Card Number');
		return false;
	}
	
    if(ExpiryDateMonth =="" || ExpiryDateYear =="") {
		alert('Please Enter Expiry Date');
		return false;
	} else if(isNaN(ExpiryDateMonth) || isNaN(ExpiryDateYear) || ExpiryDateMonth.length>2 || ExpiryDateYear.length!=4){
		alert('Please Enter valid Expiry Date');
		return false;
	}
	
	if(IssueNo !="") {
		if(IssueNo.length>15) {
			alert('Please Enter valid Issue No.');
			return false;
		}
	} 
	 
	if(CVV =="") {
		alert('Please Enter CVV');
		return false;
	} else if(CVV.length>3 || isNaN(CVV)){
		alert('Please Enter valid CVV');
		return false;
	}
	if(Paymentamount =="") {
		alert('Please Enter Payment amount');
		return false;
	} 
	if(TopupAmount =="") {
		alert('Please Select Topup Amount');
		return false;
	} 
	if(SimType =="") {
		alert('Please Select Sim Type');
		return false;
	} 
	
	if(NoofSim =="") {
		alert('Please Enter Number of Sims');
		return false;
	}else if(NoofSim.length > 1){
		alert('Number of Sims are Exceeded');
		return false;
	    
	}
	
    if(BillingHouseNo == "") {
	    alert("Please Enter Billing House No.");
	    return false;
    }

    if(BillingStreet == "") {
	    alert("Please Enter Billing Street");
	    return false;
    }

    /*if(BillingCounty == "") {
	    alert("Please Enter Billing County");
	    return false;
    }*/

    if(BillingCity == "") {
	    alert("Please Enter Billing City");
	    return false;
    }

    if(BillingPostCode == "") {
        if(localStorage.CountryCode == "USA"){
			alert("Please Enter Zip Code");
		}else{
			alert("Please Enter PostCode");
		}
		return false;
	}else if(BillingPostCode.length>10 ){
		
		if(localStorage.CountryCode == "USA"){
			alert("Please Enter valid Zip Code");
		}else{
			alert('Please Enter valid PostCode');
		}
		return false;
	}
	
	if(localStorage.CountryCode == "USA")
		var spclCharVal1 = isSpclChar(BillingPostCode,"ZipCode");
	else
		var spclCharVal1 = isSpclChar(BillingPostCode,"PostCode");
	
	if(spclCharVal == false){
		return false;
	}
    
    if($("#requestSimWithTopup").text() == "Processing..."){
        return false;
    }

    $("#requestSimWithTopup").html("Processing...");
    
    var SimRequestJSON = {
			    "Title" : Title,
			    "FirstName" : FirstName,
			    "LastName" : LastName,
			    "DateOfBirth" : DateOfBirth,
			    "EmailAddress" : EmailAddress,
			    "ContactNumber" : ContactNumber,
			    "HearAboutUs" : HearAboutUs,
			    "CallMostCountry" : CallMostCountry,
			    "Language" : Language,
			    "Promocode" : Promocode,
			    "Nationality" : Nationality,
			    "TypeofPermit" : "test",
			    "SimType" : SimType,
			    "IDNumber" : "123",
			    "CardType" : CardType,
	            "NameOnCard" : NameOnCard,
	            "CardNo" : CardNo,
	            "IssueDate" : IssueDateMonth + IssueDateYear,
	            "IssueNo" : IssueNo,
	            "ExpiryDate" : ExpiryDateMonth + ExpiryDateYear,
	            "CVV" : CVV,
	            "Paymentamount" : Paymentamount,
	            "TopupAmount" : TopupAmount,
	            "NoofSim" : NoofSim,
			    "Address" : {
				    "PostCode" : PostCode,
				    "Street" : Street,
				    "City" : City,
                    "County" : County,
				    "HouseNo" : HouseNo,
			    },
			    "BillingAddress" : {
				    "PostCode" : BillingPostCode,
				    "Street" : BillingStreet,
				    "City" : BillingCity,
                    "County" : BillingCounty,
				    "HouseNo" : BillingHouseNo,
			    },
			    "CountryCode" : localStorage.CountryCode,
			    "LanguageCode" : localStorage.LanguageCode,
			    "BrandCode" : localStorage.BrandCode
		    }
		    
	SimRequestJSON = JSON.stringify(SimRequestJSON);
    var simRequest_url = localStorage.portAddress+"FreeSimWithCredit";
    
	ldr.show();
	 $.ajax({
		type:'post',
		url: simRequest_url,
		data: SimRequestJSON,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			$("#requestSimWithTopup").html("SUBMIT");
			
		 	if(res.Response['ResponseCode'] == "0")
			{
				alert(res.Response['ResponseDesc']);
				
			}else if(res.Response['ResponseCode'] == "3D"){
				
				//storing responseobject in localstorage
				localStorage.inputObj = SimRequestJSON;
				localStorage.TRANSCTIONID = res.TopUp.TRANSCTIONID;
				localStorage.pageFrom = "RequestSimWithCredit";
				localStorage.pageURL = localStorage.portAddress+"FreeSimWithCredit3D";
				
				//var postUrl = localStorage.portNumber+"/PHPFiles/3dsecure.php?action_url="+escape(res.TopUp.TDS_ACSURL)+"&pareq_value="+escape(res.TopUp.TDS_PAREQ)+"&md_value="+escape(res.TopUp.REDORDERID);
				var postUrl = localStorage.paymentAddress+"action_url="+escape(res.TopUp.TDS_ACSURL)+"&pareq_value="+escape(res.TopUp.TDS_PAREQ)+"&md_value="+escape(res.TopUp.REDORDERID);
				window.location = postUrl;
			}
			else{
				alert(res.Response['ResponseDesc']);
			}
			
		},
		error: function(xhr)
		{
			ldr.hide();
			$("#requestSimWithTopup").html("SUBMIT");
			//alert(xhr.statusText);
		}
	});

});

});

//copying the address field values to billing address
function check_mailingAddress(){
    
    if(document.getElementById("mailing_address").checked)
    {
        var HouseNo = $.trim($("#HouseNo").val());
        var County = $.trim($("#County").val());
        var Street = $.trim($("#Street").val());
        var City = $.trim($("#City").val());
        var PostCode = $.trim($("#PostCode").val());
        
        $("#BillingHouseNo").val(HouseNo);
        $("#BillingCounty").val(County);
        $("#BillingStreet").val(Street);
        $("#BillingCity").val(City);
        $("#BillingPostCode").val(PostCode);
    }

}
