var emailpattern = /^([A-Za-z0-9_\-\.\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~\+])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
$(function(){

$("#requestFreeSIM").click(function(){
    var Title = $.trim($("#Title").val());
    var FirstName = $.trim($("#FirstName").val());
    var LastName = $.trim($("#LastName").val());
    
    var dob = $("#DateOfBirth").val();
    var dob_arr = dob.split('/');
    var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
	
    /*var dob = $("#DateOfBirth").val();//mmddyyyy
    var dob_arr = dob.split('/');
    if(localStorage.DateTimeFormat == "dd/MM/yyyy")
    {
    	var DateOfBirth = dob_arr[1]+dob_arr[0]+dob_arr[2];
    }
    if(localStorage.DateTimeFormat == "MM/dd/yyyy")
    {
    	var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
    }*/
    var Language = $.trim($("#Language").val());
    var SimType = $.trim($("#SimType").val());
    var Nationality = $.trim($("#Nationality").val());
    var EmailAddress = $.trim($("#EmailAddress").val());
    var cEmailAddress = $.trim($("#cEmailAddress").val());
    var ContactNumber = $.trim($("#ContactNumber").val());
    var HearAboutUs = $.trim($("#HearAboutUs").val());
    var CallMostCountry = $.trim($("#CallMostCountry").val());
    var HouseNo = $.trim($("#HouseNo").val());
    var Street = $.trim($("#Street").val());
    var City = $.trim($("#City").val());
    var PostCode = $.trim($("#PostCode").val());
    var Countrycode = localStorage.CountryCode;
	var LanguageCode = localStorage.LanguageCode;
	var BrandCode = localStorage.BrandCode;
	
	 if(Title == "") {
		alert("Please Select Title");
		return false;
	}

    if(FirstName == "") {
		alert("Please Enter First Name");
		return false;
	}

    if(LastName == "") {
		alert("Please Enter Last Name");
		return false;
	}

    if(DateOfBirth == "") {
		alert("Please Select Date Of Birth");
		return false;
	}

    if(EmailAddress == "") {
		alert("Please Enter Email Address");
		return false;
	}
    if(!EmailAddress.match(emailpattern)) {
		alert("Please Enter Valid Email Address");
		return false;
	}
	
	if(cEmailAddress == "") {
		alert("Please Enter Confirm Email Address");
		return false;
	}
    if(!cEmailAddress.match(emailpattern)) {
		alert("Please Enter Valid Confirm Email Address");
		return false;
	}
	if(cEmailAddress != EmailAddress)
	{
	    alert("Confirm Email Address and Email Address not match");
		return false;
	}
	
    if(Nationality == "") {
		alert("Please Enter Nationality");
		return false;
	}
	
    if(ContactNumber == "") {
		alert("Please Enter Contact Number");
		return false;
	}

    if(HouseNo == "") {
		alert("Please Enter House No.");
		return false;
	}

    if(Street == "") {
		alert("Please Enter Street");
		return false;
	}

    if(City == "") {
		alert("Please Enter City");
		return false;
	}

    if(PostCode == "") {
        if(localStorage.CountryCode == "USA"){
			alert("Please Enter Zip Code");
		}else{
			alert("Please Enter PostCode");
		}
		return false;
	}else if(PostCode.length>10 ){
		
		if(localStorage.CountryCode == "USA"){
			alert("Please Enter valid Zip Code");
		}else{
			alert('Please Enter valid PostCode');
		}
		return false;
	}

	if(localStorage.CountryCode == "USA")
		var spclCharVal = isSpclChar(PostCode,"ZipCode");
	else
		var spclCharVal = isSpclChar(PostCode,"PostCode");
	
	if(spclCharVal == false){
		return false;
	}
	
    if(HearAboutUs == "") {
		alert("Please Select How did you hear aboutus");
		return false;
	}

    if(CallMostCountry == "") {
		alert("Please Select Country you call mostly");
		return false;
	}

    if(SimType == "") {
		alert("Please Select Sim type");
		return false;
	}
	
    if(Language == "") {
		alert("Please Select Language");
		return false;
	}
	
    
    if($("#requestFreeSIM").text() == "Processing..."){
        return false;
    }
	
    $("#requestFreeSIM").html("Processing...");
	
    var SimRequestJSON = {
			    "Title" : Title,
			    "FirstName" : FirstName,
			    "LastName" : LastName,
			    "DateOfBirth" : DateOfBirth,
			    "EmailAddress" : EmailAddress,
			    "ContactNumber" : ContactNumber,
			    "HearAboutUs" : HearAboutUs,
			    "CallMostCountry" : CallMostCountry,
			    "Language" : Language,
			    "TypeofPermit" : "test",
			    "SimType" : SimType,
			    "IDNumber" : "123",
			    "Address" : {
				    "PostCode" : PostCode,
				    "Street" : Street,
				    "City" : City,

				    "HouseNo" : HouseNo,
			    },
			    "CountryCode" : localStorage.CountryCode,
			    "LanguageCode" : localStorage.LanguageCode,
			    "BrandCode" : localStorage.BrandCode
		    }
		    
	SimRequestJSON = JSON.stringify(SimRequestJSON);
    var simRequest_url = localStorage.portAddress+"FreeSimWithoutCredit";
	 ldr.show();
	 $.ajax({
		type:'post',
		url: simRequest_url,
		data: SimRequestJSON,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			$("#requestFreeSIM").html("SUBMIT");
			//alert(JSON.stringify(res));
			alert("You have successfully requested for Free SIM");
			
		},
		error: function(xhr)
		{
			ldr.hide();
			$("#requestFreeSIM").html("SUBMIT");
			//alert(xhr.statusText);
		}
	});

});


});
