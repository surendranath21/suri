var emailpattern = /^([A-Za-z0-9_\-\.\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~\+])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;  //ex:-someone.me@mail.com
$(function() {
$("#updateDetails").click(function() {

    var Title = $("#Title").val();
    var FirstName = $("#FirstName").val();
    var LastName = $("#LastName").val();
    
    var dob = $("#DateOfBirth").val();
    var dob_arr = dob.split('/');
    var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
	
    /*var dob = $("#DateOfBirth").val();//mmddyyyy
    var dob_arr = dob.split('/');
    if(localStorage.DateTimeFormat == "dd/MM/yyyy")
    {
    	var DateOfBirth = dob_arr[1]+dob_arr[0]+dob_arr[2];
    }
    if(localStorage.DateTimeFormat == "MM/dd/yyyy")
    {
    	var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
    }*/
    
    var EmailAddress = $("#EmailAddress").val();
    var cEmailAddress = $("#cEmailAddress").val();
    var ContactNumber = $("#ContactNumber").val();
    var HouseNo = $("#HouseNo").val();
    var Street = $("#Street").val();
    var County = $("#County").val();
    var City = $("#City").val();
    var PostCode = $("#PostCode").val();
    var Country = $("#Country").val();
    var HearAboutUs = $("#HearAboutUs").val();
    var CallMostCountry = $("#CallMostCountry").val();
    var Language = $("#Language").val();
	
    if(Title == "") {
		alert("Please Select Title");
		return false;
	}

    if(FirstName == "") {
		alert("Please Enter First Name");
		return false;
	}

    if(LastName == "") {
		alert("Please Enter Last Name");
		return false;
	}

    if(DateOfBirth == "") {
		alert("Please Select Date Of Birth");
		return false;
	}

    if(EmailAddress == "") {
		alert("Please Enter Email Address");
		return false;
	}
    if(!EmailAddress.match(emailpattern)) {
		alert("Please Enter Valid Email Address");
		return false;
	}
	
	if(cEmailAddress == "") {
		alert("Please Enter Confirm Email Address");
		return false;
	}
    if(!cEmailAddress.match(emailpattern)) {
		alert("Please Enter Valid Confirm Email Address");
		return false;
	}
	if(cEmailAddress != EmailAddress)
	{
	    alert("Confirm Email Address and Email Address not match");
		return false;
	}
	
    if(ContactNumber == "") {
		alert("Please Enter Contact Number");
		return false;
	}

    if(HouseNo == "") {
		alert("Please Enter House No.");
		return false;
	}

    if(Street == "") {
		alert("Please Enter Street");
		return false;
	}

   if(County.length>50){
		if(localStorage.CountryCode == "USA"){
			alert('State sholud be below 50 Char.');
		}else{
			alert('County sholud be below 50 Char.');
		}
		return false;
	}

    if(City == "") {
		alert("Please Enter City");
		return false;
	}
	
	if(PostCode == "") {
        if(localStorage.CountryCode == "USA"){
			alert("Please Enter Zip Code");
		}else{
			alert("Please Enter PostCode");
		}
		return false;
	}else if(PostCode.length>10 ){
		
		if(localStorage.CountryCode == "USA"){
			alert("Please Enter valid Zip Code");
		}else{
			alert('Please Enter valid PostCode.');
		}
		return false;
	}
	
	if(localStorage.CountryCode == "USA")
		var spclCharVal = isSpclChar(PostCode,"ZipCode");
	else
		var spclCharVal = isSpclChar(PostCode,"PostCode");
	
	if(spclCharVal == false){
		return false;
	}

    if(Country == "") {
		alert("Please Select Country");
		return false;
	}

    if(HearAboutUs == "") {
		alert("Please Select How did you hear aboutus");
		return false;
	}

    if(CallMostCountry == "") {
		alert("Please Select Country you call mostly");
		return false;
	}
	
    if(Language == "") {
		alert("Please Select Language");
		return false;
	}
	
	if(document.getElementById('chkEmail').checked){
	    var chkEmail = "true";
	}else{
	    var chkEmail = "false";
	}
	
	if(document.getElementById('chkTerms').checked){
	    var chkTerms = "true";
	}else{
	    var chkTerms = "false";
	}
	
    var requestJSON = '{"Title" :"'+Title+'","FirstName" : "'+FirstName+'","LastName" : "'+LastName+'","DateOfBirth" : "'+DateOfBirth+'","EmailAddress" : "'+EmailAddress+'","ContactNumber" : "'+ContactNumber+'","chkEmail" : "'+chkEmail+'","chkTerms" : "'+chkTerms+'","HearAboutUs" : "'+HearAboutUs+'","CallMostCountry" : "'+CallMostCountry+'","MobileNumber" : "'+localStorage.MSISDN+'","PUK" : "'+localStorage.PUK+'","LanguageID" : "'+Language+'","Address" : {"PostCode" : "'+PostCode+'","Street" : "'+Street+'","City" : "'+City+'","Country" : "'+Country+'","HouseNo" : "'+HouseNo+'","County" : "'+County+'"},"CountryCode" : "'+localStorage.CountryCode+'","LanguageCode" : "'+localStorage.LanguageCode+'","BrandCode" : "'+localStorage.BrandCode+'"}';
    
    //var requestJSON = JSON.stringify(requestJSON);
    var update_url = localStorage.portAddress+"UpdateSubscriber";
    ldr.show();
    $.ajax({
		type:'post',
		url: update_url,
		data: requestJSON,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			//alert(JSON.stringify(res));
			if(res.ResponseCode == "0")
			{
				alert("Personal Details updated successfully");
				
			}else {
				alert(res.ResponseDesc);
			}
		},
		error: function(xhr)
		{
			ldr.hide();
			//alert(xhr.statusText);
		}
	});
	
});

//update password
$("#updatePassword").click(function(){
    var OldPassword = $.trim($("#OldPassword").val());
    var NewPassword = $.trim($("#NewPassword").val());
    var cNewPassword = $.trim($("#cNewPassword").val());
    
    if(OldPassword == "")
    {
        alert("Please enter old Password");
        return false;
    }
    if(NewPassword == "")
    {
        alert("Please enter new Password");
        return false;
    }
    if(cNewPassword == "")
    {
        alert("Please enter confirm new Password");
        return false;
    }
    
    if(NewPassword != cNewPassword)
    {
        alert("Passwords are not match");
        return false;
    }
    
    var passwordJson = {
			"CountryCode" : localStorage.CountryCode,
			"LanguageCode" : localStorage.LanguageCode,
			"BrandCode" : localStorage.BrandCode,
			"MSISDN" : localStorage.MSISDN,
			"OldPassword" : OldPassword,
			"NewPassword" : NewPassword
		};
		
    passwordJson = JSON.stringify(passwordJson);
		
    var updatePassword_url =localStorage.portAddress+'ChangePassword';
	ldr.show();
    $.ajax({
		type:'post',
		url: updatePassword_url,
		data: passwordJson,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			if(res.ResponseCode == "0")
			{
				alert(res.ResponseDesc);
				localStorage.remember = false;
				localStorage.removeItem('rememberMSISDN');
				localStorage.removeItem('rememberPassword');
			}else {
				alert(res.ResponseDesc);
			}
		},
		error: function(xhr)
		{
			ldr.hide();
			//alert(xhr.statusText);
		}
	});
	
    
});
});
