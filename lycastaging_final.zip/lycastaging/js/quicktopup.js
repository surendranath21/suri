var emailpattern = /^([A-Za-z0-9_\-\.\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~\+])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;  //ex:-someone.me@mail.com
function quickTopup() {
	var MSISDN = $("#MSISDN").val();
	var TopUpAmount = $("#TopUpAmount").val();
	var Email = $("#Email").val();
	var CardType = $("#CardType").val();
	var NameOnCard = $("#NameOnCard").val();
	var CardNo = $("#CardNo").val();
	var IssueDateMonth = $("#IssueDateMonth").val();
	var IssueDateYear = $("#IssueDateYear").val();
	var ExpiryDateMonth = $("#ExpiryDateMonth").val();
	var ExpiryDateYear = $("#ExpiryDateYear").val();
	var IssueNo = $("#IssueNo").val();
	var CVV = $("#CVV").val();
	var HouseNo = $("#HouseNo").val();
	var Street = $("#Street").val();
	var County = $("#County").val();
	var City = $("#City").val();
	var PostCode = $("#PostCode").val();
	var Country = $("#Country").val();
	
	if(MSISDN=='') {
		 alert('Please Enter Mobile Number');
		 return false;
	} else if(MSISDN.length>15) {
		 alert('Please Enter Mobile Number below 15 characters');
		 return false;
	}
	
	if(TopUpAmount=="") {
		alert('Please Select TopUpAmount');
		return false;
	} else if(TopUpAmount.length>2){
		alert('Invalid TopUpAmount');
		return false;
	}
	
	if(Email=="") {
		alert('Please Enter Email');
		return false;
	} else if(Email.length>50){
		alert('Please Enter Email Address Upto 50 characters');
		return false;
	} else if(!Email.match(emailpattern)){
		alert('Please Enter valid Email');
		return false;
	}
	
	if(CardType=="") {
		alert('Please Select CardType');
		return false;
	} else if(CardType.length>50){
		alert('Please Enter valid CardType');
		return false;
	}
	
	if(NameOnCard=="") {
		alert('Please Enter NameOnCard');
		return false;
	} else if(NameOnCard.length>50){
		alert('NameOnCard should be Below 50 Char.');
		return false;
	}
	
	if(CardNo =="") {
		alert('Please Enter CardNo');
		return false;
	} else if(CardNo.length>16 || isNaN(CardNo)){
		alert('Please Enter valid CardNo.');
		return false;
	}
	
	/*if(IssueDateMonth =="" || IssueDateYear =="") {
		alert('Please Enter Issue Date');
		return false;
	} else if(isNaN(IssueDateMonth) || isNaN(IssueDateYear) || IssueDateMonth.length > 2 || IssueDateYear.length!=4){
		alert('Please Enter valid Issue Date');
		return false;
	}*/
	
	if(ExpiryDateMonth =="" || ExpiryDateYear =="") {
		alert('Please Enter Expiry Date');
		return false;
	}else if(isNaN(ExpiryDateMonth) || isNaN(ExpiryDateYear) || ExpiryDateMonth.length > 2 || ExpiryDateYear.length!=4)
	{
		alert('Please Enter valid Expiry Date');
		return false;
	}
	
	if(IssueNo !="") {
		if(IssueNo.length>16) {
			alert('Please Enter valid IssueNo.');
			return false;
		}
	} 
	 
	if(CVV =="") {
		alert('Please Enter CVV');
		return false;
	} else if(CVV.length != 3){
		alert('Please Enter valid CVV');
		return false;
	}

	if(HouseNo =="") {
		alert('Please Enter HouseNo.');
		return false;
	} else if(HouseNo.length>10){
		alert('Please Enter valid HouseNo.');
		return false;
	}
	 
	if(Street =="") {
		alert('Please Enter Street');
		return false;
	} else if(Street.length>50){
		alert('Street name sholud be below 50 Char.');
		return false;
	}
	
	/*if(County =="") {
		alert('Please Enter County');
		return false;
	} else*/ if(County.length>50){
		if(localStorage.CountryCode == "USA"){
			alert('State sholud be below 50 Char.');
		}else{
			alert('County sholud be below 50 Char.');
		}
		return false;
	}
	
	if(City =="") {
		alert('Please Enter City');
		return false;
	} else if(City.length>50){
		alert('City sholud be below 50 Char.');
		return false;
	}
	
	if(PostCode == "") {
        if(localStorage.CountryCode == "USA"){
			alert("Please Enter Zip Code");
		}else{
			alert("Please Enter PostCode");
		}
		return false;
	}else if(PostCode.length>10 ){
		
		if(localStorage.CountryCode == "USA"){
			alert("Please Enter valid Zip Code");
		}else{
			alert('Please Enter valid PostCode');
		}
		return false;
	}
	if(localStorage.CountryCode == "USA")
		var spclCharVal = isSpclChar(PostCode,"ZipCode");
	else
		var spclCharVal = isSpclChar(PostCode,"PostCode");
	
	if(spclCharVal == false){
		return false;
	}
	
	if(Country =="") {
		alert('Please Select Country');
		return false;
	} 
	
    if($("#quickTopup").text() == "Processing..."){
        return false;
    }
    
	if(localStorage.CountryCode == "USA" && MSISDN.charAt(0) != "1") {
		
		var mobiIndex = "1";
		MSISDN = mobiIndex.concat(MSISDN);
		
	}

	if(localStorage.CountryCode == "GBR" && MSISDN.charAt(0) == "0"){
	    MSISDN = localStorage.mobileIndex+MSISDN.substring(1, MSISDN.length);
	}
    
	$("#quickTopup").html("Processing...");
	
	var quicktopupJSON = {
		"MSISDN" : MSISDN,
		"TopUpAmount" : TopUpAmount,
		"Email" : Email,
		"CardType" : CardType,
		"NameOnCard" : NameOnCard,
		"CardNo" : CardNo,
		"IssueDate" : IssueDateMonth+IssueDateYear,
		"IssueNo" : IssueNo,
		"ExpiryDate" : ExpiryDateMonth+ExpiryDateYear,
		"CVV" : CVV,
		"Address" : {
			"PostCode" : PostCode,
			"Street" : Street,
			"City" : City,
			"HouseNo" : HouseNo,
			"County" : County,
			"Country" : Country
		},
		"CountryCode" : localStorage.CountryCode,
		"LanguageCode" : localStorage.LanguageCode,
		"BrandCode" : localStorage.BrandCode
	};
	quicktopupJSON = JSON.stringify(quicktopupJSON);
	var quicktopup_url = localStorage.portAddress+"DoQuickTopUp";
    ldr.show();
    $.ajax({
		type:'post',
		url: quicktopup_url,
		data: quicktopupJSON,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			$("#quickTopup").html("SUBMIT");
			//alert(JSON.stringify(res));
			if(res.Response['ResponseCode'] == "0"){
				alert(res.Response['ResponseDesc']);
			}else if(res.Response['ResponseCode'] == "3D"){
				
				//storing responseobject in localstorage
				localStorage.inputObj = quicktopupJSON;
				localStorage.TRANSCTIONID = res.TopUp.TRANSCTIONID;
				localStorage.pageFrom = "quicktopup";
				localStorage.pageURL = localStorage.portAddress+"DoQuickTopUp3D";
				
				//var postUrl = localStorage.portNumber+"/PHPFiles/3dsecure.php?action_url="+escape(res.TopUp.TDS_ACSURL)+"&pareq_value="+escape(res.TopUp.TDS_PAREQ)+"&md_value="+escape(res.TopUp.REDORDERID);
				var postUrl = localStorage.paymentAddress+"action_url="+escape(res.TopUp.TDS_ACSURL)+"&pareq_value="+escape(res.TopUp.TDS_PAREQ)+"&md_value="+escape(res.TopUp.REDORDERID);
				window.location = postUrl;
				
			}else {
				alert(res.Response['ResponseDesc']);
			}
		},
		error: function(xhr)
		{
			$("#quickTopup").html("SUBMIT");
			ldr.hide();
		}
	});
	
}
