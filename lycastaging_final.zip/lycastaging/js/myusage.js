var voiceArray = new Array();
var smsArray = new Array();
var dataArray = new Array();
$(function(){
	$("#BalanceRemain").click(function(){
		$("#recentTopupDiv").show();
		$("#smsusageDiv").hide();
		$("#datausageDiv").hide();
		$("#voiceusageDiv").hide();
		
		$("#BalanceRemain").addClass("mybox_selected");
		$("#VoiceCalls").removeClass("mybox_selected");
		$("#SMSUsed").removeClass("mybox_selected");
		$("#DataUsed").removeClass("mybox_selected");
		
		$("#balance_remaining").html("");
		
		//GetCallHistory
		var balanceUrl = localStorage.portAddress+"GetAccountBalance";
		var balParameters = '{"MSISDN":"'+localStorage.MSISDN+'","CountryCode":"'+localStorage.CountryCode+'","LanguageCode":"'+localStorage.LanguageCode+'","BrandCode":"'+localStorage.BrandCode+'"}';
		ldr.show();
		$.ajax({
			type:'post',
			url: balanceUrl,
			data: balParameters,
			async: true,
			contentType:'application/json',
			success:function(res)
			{
				ldr.hide();
				var bal = res.Balance;
				$("#balance_remaining").html(bal.substring(0,(bal.length-2)));
			},
			error: function(xhr)
			{
				ldr.hide();
				//alert(xhr.statusText);
			}
		});
		
	});
	$("#VoiceCalls").click(function(){
		$("#recentTopupDiv").hide();
		$("#smsusageDiv").hide();
		$("#datausageDiv").hide();
		$("#voiceusageDiv").show();
		
		$("#BalanceRemain").removeClass("mybox_selected");
		$("#VoiceCalls").addClass("mybox_selected");
		$("#SMSUsed").removeClass("mybox_selected");
		$("#DataUsed").removeClass("mybox_selected");
		
		$("#voice_data").html("");
		if(voiceArray.length >0){
				var voiceDetails = '<table id="voicetable" width="100%" border="0" cellspacing="0" cellpadding="0"><tr style="background-color: transparent;"><td colspan="2"><strong>Voice Usage</strong></td><td colspan="2" align="right"><a onclick="postToFeed(); return false;"><img src="img/fshare.png" width="62" height="24" border="0" class="pointer"></a></td></tr><tr style="background-color:#03497d;"><td>Date</td><td>Time</td><td align="right">Phone</td><td align="right">Amount</td></tr>';

				var cal = 1;
				var voice_style = "";
				
				for(var i=0;i<voiceArray.length;i++){
					if((i+1)%10 == 0){
						cal++;
						voice_style= " style='display:none;'";
					}
					voiceDetails += "<tr class='voiceDiv_"+cal+"' "+voice_style+"><td>"+voiceArray[i]['Date']+'</td><td>'+voiceArray[i]['Time']+'</td><td align="right">'+voiceArray[i]['CalledNumber']+'</td><td align="right">'+voiceArray[i]['Cost'].substring(0,(voiceArray[i]['Cost'].length-2))+"</td></tr>";
				}
				if(i >10){
					voiceDetails += '</table><div><button class="paginateBtn" id="voice_prev" style="background-color:#23d36a;" onclick="showPrevious(\'voice\')">Prev</button><button class="paginateBtn" id="voice_next" onclick="showNext(\'voice\')">Next</button></div>';
				}else{
					voiceDetails += '</table>';
				}
				
				$("#voice_data").html(voiceDetails);

				$("#voice_count").val(i);
			}
	});
	$("#SMSUsed").click(function(){
		$("#recentTopupDiv").hide();
		$("#smsusageDiv").show();
		$("#datausageDiv").hide();
		$("#voiceusageDiv").hide();
		
		$("#BalanceRemain").removeClass("mybox_selected");
		$("#VoiceCalls").removeClass("mybox_selected");
		$("#SMSUsed").addClass("mybox_selected");
		$("#DataUsed").removeClass("mybox_selected");
		
		$("#sms_data").html("");
		
		if(smsArray.length >0){
			var smsDetails = '<table id="smstable" width="100%" border="0" cellspacing="0" cellpadding="0"><tr style="background-color: transparent;"><td colspan="2"><strong>SMS Usage</strong></td><td colspan="2" align="right"><a onclick="postToFeed(); return false;"><img src="img/fshare.png" width="62" height="24" border="0" class="pointer"></a></td></tr><tr style="background-color:#03497d;"><td>Date</td><td>Time</td><td align="right">Phone</td><td align="right">Amount</td></tr>';

			var cal = 1;
			var sms_style = "";
			
			for(var i=0;i<smsArray.length;i++){
				if((i+1)%10 == 0){
					cal++;
					sms_style= " style='display:none;'";
				}
				smsDetails += "<tr class='smsDiv_"+cal+"' "+sms_style+"><td>"+smsArray[i]['Date']+'</td><td>'+smsArray[i]['Time']+'</td><td align="right">'+smsArray[i]['CalledNumber']+'</td><td align="right">'+smsArray[i]['Cost'].substring(0,(smsArray[i]['Cost'].length-2))+"</td></tr>";
			}
			if(i >10){
				smsDetails += '</table><div><button class="paginateBtn" id="sms_prev" style="background-color:#23d36a;" onclick="showPrevious(\'sms\')">Prev</button><button class="paginateBtn" id="sms_next" onclick="showNext(\'sms\')">Next</button></div>';
			}else{
				smsDetails += '</table>';
			}
			
			$("#sms_data").html(smsDetails);

			$("#sms_count").val(i);
		}
		
	});
	$("#DataUsed").click(function(){
		$("#recentTopupDiv").hide();
		$("#smsusageDiv").hide();
		$("#datausageDiv").show();
		$("#voiceusageDiv").hide();
		
				
		$("#BalanceRemain").removeClass("mybox_selected");
		$("#VoiceCalls").removeClass("mybox_selected");
		$("#SMSUsed").removeClass("mybox_selected");
		$("#DataUsed").addClass("mybox_selected");
		
	});
	
});

function showPrevious(page){
	var pagenum = $("#"+page+"_page").val();
	var records_count = $("#"+page+"_count").val();
	var num_pages = Math.ceil(records_count/10); 
	
	if(pagenum !=1){
		var hide_class = "."+page+"Div_"+pagenum;
		pagenum--;
		var show_class = "."+page+"Div_"+pagenum;
		
		$(hide_class).hide();
		$(show_class).show();
		
		$("#"+page+"_page").val(pagenum);
		
		$("#"+page+"_prev").css("background-color","#0BB14E");
		$("#"+page+"_next").css("background-color","#0BB14E");
	}else{
		$("#"+page+"_prev").css("background-color","#23d36a");
		$("#"+page+"_next").css("background-color","#0BB14E");
	}
	
	if(pagenum == 1){
		$("#"+page+"_prev").css("background-color","#23d36a");
	}
}

function showNext(page){
	var pagenum = $("#"+page+"_page").val();
	var records_count = $("#"+page+"_count").val();
	var num_pages = Math.ceil(records_count/10); 
	
	if(num_pages > pagenum){
		var hide_class = "."+page+"Div_"+pagenum;
		pagenum++;
		var show_class = "."+page+"Div_"+pagenum;
		
		$(hide_class).hide();
		$(show_class).show();
		
		$("#"+page+"_page").val(pagenum);
		
		$("#"+page+"_prev").css("background-color","#0BB14E");
		$("#"+page+"_next").css("background-color","#0BB14E");
	}else{
		$("#"+page+"_next").css("background-color","#23d36a");
		$("#"+page+"_prev").css("background-color","#0BB14E");
	}
	
	if(num_pages == pagenum){
		$("#"+page+"_next").css("background-color","#23d36a");
	}
	
}

function searchTable(tabName){
	
	var inputVal = $("#"+tabName+"_search").val();
	var Details = "";
	$("#"+tabName+"_data").html("");
	
	var search_arr = "";
	if(tabName == "voice"){
		var search_arr = voiceArray;
	} 
	if(tabName == "sms"){
		var search_arr = smsArray;
	} 
	
	if(search_arr.length >0)
	{
		Details = '<table id="'+tabName+'table" width="100%" border="0" cellspacing="0" cellpadding="0"><tr style="background-color: transparent;"><td colspan="2"><strong>'+tabName+' Usage</strong></td><td colspan="2" align="right"><a onclick="postToFeed(); return false;"><img src="img/fshare.png" width="62" height="24" border="0" class="pointer"></a></td></tr><tr style="background-color:#03497d;"><td>Date</td><td>Time</td><td align="right">Phone</td><td align="right">Amount</td></tr>';

		var cal = 1;
		var style = "";
		var callcount = 0;
			
		for(var i=0;i<search_arr.length;i++)
		{
			if(search_arr[i]['CalledNumber'].indexOf(inputVal) != "-1")
			{
				if((callcount+1)%10 == 0){
					cal++;
					style= " style='display:none;'";
				}
				
				Details += "<tr class='"+tabName+"Div_"+cal+"' "+style+"><td>"+search_arr[i]['Date']+'</td><td>'+search_arr[i]['Time']+'</td><td align="right">'+search_arr[i]['CalledNumber']+'</td><td align="right">'+search_arr[i]['Cost'].substring(0,(search_arr[i]['Cost'].length-2))+"</td></tr>";
				callcount++;
			}
		}
		if(callcount >10){
			Details += '</table><div><button class="paginateBtn" id="'+tabName+'_prev" style="background-color:#23d36a;"  onclick="showPrevious(\''+tabName+'\')">Prev</button><button class="paginateBtn"  id="'+tabName+'_next" onclick="showNext(\''+tabName+'\')">Next</button></div>';
		}else{
			Details += '</table>';
		}
		$("#"+tabName+"_data").html(Details);
		
		$("#"+tabName+"_count").val(callcount);
	}
	
	
	
}