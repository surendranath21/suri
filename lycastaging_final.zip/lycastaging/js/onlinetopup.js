var emailpattern = /^([A-Za-z0-9_\-\.\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~\+])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;  //ex:-someone.me@mail.com
function onlineTopup() {
	var d = new Date();
	var TopUpAmount = $("#TopUpAmount").val();
	var BalanceLimit = $("#BalanceLimit").val();
	var MaxLimit = $("#MaxLimit").val();
	var PerWeek = $("#PerWeek").val();
	var Email = $("#Email").val();
	var CardType = $("#CardType").val();
	var NameOnCard = $("#NameOnCard").val();
	var CardNo = $("#CardNo").val();
	var IssueDateMonth = $("#IssueDateMonth").val();
	var IssueDateMonth = $("#IssueDateYear").val();
	var ExpiryDateMonth = $("#ExpiryDateMonth").val();
	var ExpiryDateYear = $("#ExpiryDateYear").val();
	
	var IssueNo = $("#IssueNo").val();
	var CVV = $("#CVV").val();
	var HouseNo = $("#HouseNo").val();
	var Street = $("#Street").val();
	var County = $("#County").val();
	var City = $("#City").val();
	var PostCode = $("#PostCode").val();
	var Country = $("#Country").val();
	var IsAutoTopUp = true;
	
	if(TopUpAmount=="") {
		alert('Please Enter TopUpAmount');
		return false;
	} else if(TopUpAmount.length>2){
		alert('Please Enter valid TopUpAmount');
		return false;
	}
	if(document.getElementById("IsAutoTopUp").checked)
	{
	    IsAutoTopUp = true;
	    if(BalanceLimit=="") {
		    alert('Please Select Balance Limit');
		    return false;
	    } else if(BalanceLimit.length>50){
		    alert('Please Enter valid Balance Limit');
		    return false;
	    }
	
	    if(MaxLimit=="") {
		    alert('Please Select Max Limit');
		    return false;
	    } else if(MaxLimit.length>2){
		    alert('Please Select valid Max Limit');
		    return false;
	    }
	
	    if(PerWeek=="") {
		    alert('Please Select Per Week');
		    return false;
	    } else if(PerWeek.length>50){
		    alert('Please Enter valid Per Week');
		    return false;
	    }
	
	}else{
	    IsAutoTopUp = false;
	}
	if(Email=="") {
		alert('Please Enter Email');
		return false;
	} else if(Email.length>50){
		alert('Please Enter Email Address Upto 50 characters');
		return false;
	} else if(!Email.match(emailpattern)){
		alert('Please Enter valid Email');
		return false;
	}
	
	/*
	if(Countrycode=="") {
		alert('Please Enter Countrycode');
		return false;
	} else if(Countrycode.length>3){
		alert('Please Enter valid Countrycode');
		return false;
	}
	*/
	
	if(CardType=="") {
		alert('Please Select CardType');
		return false;
	} else if(CardType.length>50){
		alert('Please Enter valid CardType');
		return false;
	}
	
	if(NameOnCard=="") {
		alert('Please Enter NameOnCard');
		return false;
	} else if(NameOnCard.length>50){
		alert('Please Enter valid NameOnCard');
		return false;
	}
	
	if(CardNo =="") {
		alert('Please Enter Card Number');
		return false;
	} else if(CardNo.length>16 || isNaN(CardNo)){
		alert('Please Enter valid Card Number');
		return false;
	}
	
	/* 
	if(IssueDateMonth =="" || IssueDateYear =="") {
		alert('Please Enter Issue Date');
		return false;
	} else if(isNaN(IssueDateMonth) || isNaN(IssueDateYear) || IssueDateMonth.length!=2 || IssueDateYear.length!=4){
		alert('Please Enter valid Issue Date');
		return false;
	}
	}*/
	
	
	if(ExpiryDateMonth =="" || ExpiryDateYear =="") {
		alert('Please Enter Expiry Date');
		return false;
	} else if(isNaN(ExpiryDateMonth) || isNaN(ExpiryDateYear) || ExpiryDateMonth.length > 2 || ExpiryDateYear.length!=4){
		alert('Please Enter valid Expiry Date');
		return false;
	}
	
	if(ExpiryDateMonth < d.getMonth() && ExpiryDateYear == d.getFullYear())
	{
		alert('Please Enter valid Expiry Date');
		return false;
	}
	
	if(ExpiryDateYear < d.getFullYear())
	{
		alert('Please Enter valid Expiry Date');
		return false;
	}
	
	if(IssueNo !="") {
		
		if(IssueNo.length>15) {
			alert('Please Enter valid Issue No.');
			return false;
		}
		
	} 
	 
	if(CVV =="") {
		alert('Please Enter CVV');
		return false;
	} else if(CVV.length>3 || isNaN(CVV)){
		alert('Please Enter valid CVV');
		return false;
	}

	if(HouseNo =="") {
		alert('Please Enter HouseNo.');
		return false;
	} else if(HouseNo.length>10 ){
		alert('Please Enter valid House No.');
		return false;
	}
	 
	if(Street =="") {
		alert('Please Enter Street');
		return false;
	} else if(Street.length>50){
		alert('Please Enter valid Street');
		return false;
	}
	
	/*if(County =="") {
		alert('Please Enter County');
		return false;
	} else*/ if(County.length>50){
		if(localStorage.CountryCode == "USA"){
			alert('State sholud be below 50 Char.');
		}else{
			alert('County sholud be below 50 Char.');
		}
		return false;
	}
	
	if(City =="") {
		alert('Please Enter City');
		return false;
	} else if(City.length>50){
		alert('Please Enter valid City');
		return false;
	}
	
	if(PostCode == "") {
        if(localStorage.CountryCode == "USA"){
			alert("Please Enter Zip Code");
		}else{
			alert("Please Enter PostCode");
		}
		return false;
	}else if(PostCode.length>10 ){
		
		if(localStorage.CountryCode == "USA"){
			alert("Please Enter valid Zip Code");
		}else{
			alert('Please Enter valid PostCode');
		}
		return false;
	}
	
	if(localStorage.CountryCode == "USA")
		var spclCharVal = isSpclChar(PostCode,"ZipCode");
	else
		var spclCharVal = isSpclChar(PostCode,"PostCode");
	
	if(spclCharVal == false){
		return false;
	}
	
	
	if(Country =="") {
		alert('Please Select Country');
		return false;
	} else if(Country.length>50){
		alert('Please Enter valid Country');
		return false;
	}
    
    if($("#onlineTopup").text() == "Processing..."){
        return false;
    }
	
	$("#onlineTopup").html("Processing...");
	


	onlinetopupJSON = {
	"MSISDN" : localStorage.MSISDN,
	"TopUpAmount" : TopUpAmount,
	"IsAutoTopup" : IsAutoTopUp,
	"Email" : Email,
	"CardType" : CardType,
	"NameOnCard" : NameOnCard,
	"CardNo" : CardNo,
	"IssueDate" : IssueDateMonth + IssueDateYear,
	"IssueNo" : IssueNo,
	"ExpiryDate" : ExpiryDateMonth + ExpiryDateYear,
	"CVV" : CVV,
	"Address" : {
		"PostCode" : PostCode,
		"Street" : Street,
		"City" : City,
		"HouseNo" : HouseNo,
		"County" : County,
		"Country" : Country
	},

	"CountryCode" : localStorage.CountryCode,
	"LanguageCode" : localStorage.LanguageCode,
	"BrandCode" : localStorage.BrandCode
    }
    
    var onlinetopupJSON = JSON.stringify(onlinetopupJSON);
    var onlinetopupUrl = localStorage.portAddress+"DoOnlineTopUp";
	ldr.show();
		$.ajax({
		type:'post',
		url: onlinetopupUrl,
		data: onlinetopupJSON,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			$("#onlineTopup").html("SUBMIT");
			//alert(JSON.stringify(res));
			if(res.Response['ResponseCode'] == "0")
			{
				alert(res.Response['ResponseDesc']);
				
			}else if(res.Response['ResponseCode'] == "3D"){
				//storing responseobject in localstorage
				localStorage.inputObj = onlinetopupJSON;
				localStorage.TRANSCTIONID = res.TopUp.TRANSCTIONID;
				localStorage.pageFrom = "onlinetopup";
				localStorage.pageURL = localStorage.portAddress+"DoOnlineTopUp3D";
				
				//var postUrl = localStorage.portNumber+"/PHPFiles/3dsecure.php?action_url="+escape(res.TopUp.TDS_ACSURL)+"&pareq_value="+escape(res.TopUp.TDS_PAREQ)+"&md_value="+escape(res.TopUp.REDORDERID);
				var postUrl = localStorage.paymentAddress+"action_url="+escape(res.TopUp.TDS_ACSURL)+"&pareq_value="+escape(res.TopUp.TDS_PAREQ)+"&md_value="+escape(res.TopUp.REDORDERID);
				window.location = postUrl;
			}
			else{
				alert(res.Response['ResponseDesc']);
			}
		},
		error: function(xhr)
		{
			ldr.hide();
			$("#onlineTopup").html("SUBMIT");
			//alert(xhr.statusText);
		}
	});
    
}

