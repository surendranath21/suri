$(function(){

$("#updateAutoTopup").click(function(){

    var TopUpAmount = $("#TopUpAmount").val();
	var BalanceLimit = $("#BalanceLimit").val();
	var MaxLimit = $("#MaxLimit").val();
	var PerWeek = $("#PerWeek").val();
	var CardKey = $("#CardKey").val();
	var CardNo = $("#CardKey option:selected").text();
	
	
	if(TopUpAmount=="") {
		alert('Please Enter TopUpAmount');
		return false;
	} else if(TopUpAmount.length>2){
		alert('Please Enter valid TopUpAmount');
		return false;
	}
	if(document.getElementById("IsAutoTopUp").checked)
	{
	    var IsAutoTopUp = "true";
	}else{
	    var IsAutoTopUp = "false";
	}
	if(BalanceLimit=="") {
	    alert('Please Select Balance Limit');
	    return false;
    } else if(BalanceLimit.length>50){
	    alert('Please Enter valid Balance Limit');
	    return false;
    }

    if(MaxLimit=="") {
	    alert('Please Select Max Limit');
	    return false;
    } else if(MaxLimit.length>2){
	    alert('Please Select valid Max Limit');
	    return false;
    }

    if(PerWeek=="") {
	    alert('Please Select Per Week');
	    return false;
    } else if(PerWeek.length>50){
	    alert('Please Enter valid Per Week');
	    return false;
    }
    if(CardKey == "") {
	    alert('Please Select Credit/Debit Card');
	    return false;
    } 
	
    if($("#updateAutoTopup").text() == "Processing..."){
        return false;
    }
	$("#updateAutoTopup").html("Processing...");
    
	var topupJSON = {
		"MSISDN" : localStorage.MSISDN,
		"TopUpAmount" : TopUpAmount,
		"IsAutoTopup" : IsAutoTopUp,
		"CountryCode" : localStorage.CountryCode,
		"BalanceLimit" : BalanceLimit,
		"MaxLimit" : MaxLimit,
		"PerWeek" : PerWeek,
		"LanguageCode" : localStorage.LanguageCode,
		"BrandCode" : localStorage.BrandCode
	}
	
	topupJSON = JSON.stringify(topupJSON);
	var autotopupUrl = localStorage.portAddress+"DoAutoTopUp";
	ldr.show();
	$.ajax({
		type:'post',
		url: autotopupUrl,
		data: topupJSON,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			//ldr.hide();
			$("#updateAutoTopup").html("SAVE");
			if(res.ResponseCode == "0")
			{
			    var CreditCardJSON = {
					"MobileNumber" : localStorage.MSISDN,
					"CountryCode" : localStorage.CountryCode,
					"TopUpAmount" : TopUpAmount,
					"BalanceLimit" : BalanceLimit,
					"CardNo" : CardNo,
					"CardKey" : CardKey,
					"LanguageCode" : localStorage.LanguageCode,
					"BrandCode" : localStorage.BrandCode
				}
				CreditCardJSON = JSON.stringify(CreditCardJSON);
				//ldr.show();
				$.ajax({
					type:'post',
					url: localStorage.portAddress+"ChangeCreditCard",
					data: CreditCardJSON,
					async: true,
					contentType:'application/json',
					success:function(res)
					{
						ldr.hide();
						$("#updateAutoTopup").html("SAVE");
						alert(res.ResponseDesc);
					},
				    error: function(xhr)
				    {
					    $("#updateAutoTopup").html("SAVE");
					    //alert(xhr.statusText);
					    ldr.hide();
				    }
			    });
				
			}else {
				alert(res.ResponseDesc);
			}
		},
		error: function(xhr)
		{
			$("#updateAutoTopup").html("SAVE");
			ldr.hide();
			//alert(xhr.statusText);
		}
	});

});

});
