var emailpattern = /^([A-Za-z0-9_\-\.\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~\+])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;  //ex:-someone.me@mail.com
$(function() {
$("#register").click(function() {

    var MSISDN = $("#MSISDN").val();
    var PUK = $("#PUK").val();
    var SecretQuestion = $("#SecretQuestion").val();
    var SecretAnswer = $("#SecretAnswer").val();
    var Title = $("#Title").val();
    var FirstName = $("#FirstName").val();
    var LastName = $("#LastName").val();
    
    var dob = $("#DateOfBirth").val();
    var dob_arr = dob.split('/');
    var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
    
    /*var dob_arr = dob.split('/');
    if(localStorage.DateTimeFormat == "dd/MM/yyyy")
    {
    	var DateOfBirth = dob_arr[1]+dob_arr[0]+dob_arr[2];
    }
    if(localStorage.DateTimeFormat == "MM/dd/yyyy")
    {
    	var DateOfBirth = dob_arr[0]+dob_arr[1]+dob_arr[2];
    }*/
    
    var EmailAddress = $("#EmailAddress").val();
    var cEmailAddress = $("#cEmailAddress").val();
    var ContactNumber = $("#ContactNumber").val();
    var HouseNo = $("#HouseNo").val();
    var Street = $("#Street").val();
    var County = $("#County").val();
    var City = $("#City").val();
    var PostCode = $("#PostCode").val();
    var Country = $("#Country").val();
    var HearAboutUs = $("#HearAboutUs").val();
    var CallMostCountry = $("#CallMostCountry").val();
    var Language = $("#Language").val();
    
	//validations
	if (MSISDN == "") {
		alert('Please Enter Mobile Number');
        return false;
	}
	if(isNaN(MSISDN)) {
		alert("Please Enter Valid Mobile Number");
		return false;
	}
	if (MSISDN.length < 10) {
		alert("Mobile Number should be at least 10 digits");
		return false;
	}
	//checking first character, if 0 replace with 44
	if(MSISDN.charAt(0) == "0"){
		MSISDN = localStorage.mobileIndex+txtMobileNum.substring(1, txtMobileNum.length);
	}
	
	if (PUK == "") {
		alert("Please Enter PUK Code");
		return false;
	}
	if(isNaN(PUK)) {
		alert("Please Enter Valid PUK Code");
		return false;
	}
	
	if(SecretQuestion == "") {
		alert("Please Select a Select Question");
		return false;
	}
	
    if(SecretAnswer == "") {
		alert("Please Enter Secret Answer");
		return false;
	}

    if(Title == "") {
		alert("Please Select Title");
		return false;
	}

    if(FirstName == "") {
		alert("Please Enter First Name");
		return false;
	}

    if(LastName == "") {
		alert("Please Enter Last Name");
		return false;
	}

    if(DateOfBirth == "") {
		alert("Please Select Date Of Birth");
		return false;
	}

    if(EmailAddress == "") {
		alert("Please Enter Email Address");
		return false;
	}
    if(!EmailAddress.match(emailpattern)) {
		alert("Please Enter Valid Email Address");
		return false;
	}
	
	if(cEmailAddress == "") {
		alert("Please Enter Confirm Email Address");
		return false;
	}
    if(!cEmailAddress.match(emailpattern)) {
		alert("Please Enter Valid Confirm Email Address");
		return false;
	}
	if(cEmailAddress != EmailAddress)
	{
	    alert("Confirm Email Address and Email Address not match");
		return false;
	}
	
    if(ContactNumber == "") {
		alert("Please Enter Contact Number");
		return false;
	}

    if(HouseNo == "") {
		alert("Please Enter House No.");
		return false;
	}

    if(Street == "") {
		alert("Please Enter Street");
		return false;
	}

    if(County.length>50){
		if(localStorage.CountryCode == "USA"){
			alert('State sholud be below 50 Char.');
		}else{
			alert('County sholud be below 50 Char.');
		}
		return false;
	}

    if(City == "") {
		alert("Please Enter City");
		return false;
	}

    if(PostCode == "") {
        if(localStorage.CountryCode == "USA"){
			alert("Please Enter Zip Code");
		}else{
			alert("Please Enter PostCode");
		}
		return false;
	}else if(PostCode.length>10 ){
		
		if(localStorage.CountryCode == "USA"){
			alert("Please Enter valid Zip Code");
		}else{
			alert('Please Enter valid PostCode');
		}
		return false;
	}
	
	if(localStorage.CountryCode == "USA")
		var spclCharVal = isSpclChar(PostCode,"ZipCode");
	else
		var spclCharVal = isSpclChar(PostCode,"PostCode");
	
	if(spclCharVal == false){
		return false;
	}

    if(Country == "") {
		alert("Please Select Country");
		return false;
	}

    if(HearAboutUs == "") {
		alert("Please Select How did you hear aboutus");
		return false;
	}

    if(CallMostCountry == "") {
		alert("Please Select Country you call mostly");
		return false;
	}
	
    if(Language == "") {
		alert("Please Select Language");
		return false;
	}
	
	if(document.getElementById('chkEmail').checked){
	    var chkEmail = true;
	}else{
	    var chkEmail = false;
	}
	
	if(document.getElementById('chkTerms').checked){
	    var chkTerms = true;
	}else{
	    var chkTerms = false;
	}
	
    var requestJSON = '{"Title" : "'+Title+'","FirstName" : "'+escape(FirstName)+'","LastName" : "'+escape(LastName)+'","DateOfBirth" : "'+DateOfBirth+'","EmailAddress" : "'+EmailAddress+'","ContactNumber" : "'+ContactNumber+'","chkEmail" : '+chkEmail+',"chkTerms" : '+chkTerms+',"HearAboutUs" : "'+HearAboutUs+'","CallMostCountry" : "'+CallMostCountry+'","MobileNumber" : "'+MSISDN+'","PUK" : "'+PUK+'","SecretQuestion" : "'+SecretQuestion+'","SecretAnswer" : "'+escape(SecretAnswer)+'","Language" : "'+Language+'","Address" : {"PostCode" : "'+PostCode+'","Street" : "'+Street+'","City" : "'+City+'","Country" : "'+Country+'","HouseNo" : "'+HouseNo+'","County" : "'+County+'"},"CountryCode" : "'+localStorage.CountryCode+'","LanguageCode" : "'+localStorage.LanguageCode+'","BrandCode" : "'+localStorage.BrandCode+'"}';
    
    //requestJSON = JSON.stringify(requestJSON);
    var register_url = localStorage.portAddress+"RegisterSubscriber";
    ldr.show();
    $.ajax({
		type:'post',
		url: register_url,
		data: requestJSON,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			//alert(JSON.stringify(res));
			if(res.ResponseCode == "0")
			{
				alert("Registration Done Successfully");
				
			}else if(res.ResponseCode == "4")
			{
				alert("Mobile Number Already Registered...");
			}
			else {
				alert(res.ResponseDesc);
			}
		},
		error: function(xhr)
		{
			ldr.hide();
			//alert(xhr.statusText);
		}
	});
	
});
});
