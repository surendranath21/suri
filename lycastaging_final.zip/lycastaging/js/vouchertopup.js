$(function() {
$("#voucherTopup").click(function(){
var Voucherpin = $("#Voucherpin").val();

if(Voucherpin == "")
{
    alert("Please Enter Voucher Number");
    return false;
}

//var voucherJSON = '{"CountryCode" : "'+localStorage.CountryCode+'","LanguageCode" : "'+localStorage.LanguageCode+'","BrandCode" :"'+ localStorage.BrandCode+'","MSISDN" :"'+ localStorage.MSISDN+'","Voucherpin" :"'+ Voucherpin+'"}';
var voucherUrl = localStorage.portAddress+"VoucherTopUp";

var voucherJSON = {
"CountryCode" : localStorage.CountryCode,
"LanguageCode" : localStorage.LanguageCode,
"BrandCode" : localStorage.BrandCode,
"MSISDN" :localStorage.MSISDN,
"Voucherpin" : Voucherpin
}

var voucherJSON = JSON.stringify(voucherJSON);
ldr.show();
$.ajax({
		type:'post',
		url: voucherUrl,
		data: voucherJSON,
		async: true,
		contentType:'application/json',
		success:function(res)
		{
			ldr.hide();
			res = JSON.parse(res);
		    
		    if(res.Response['ResponseCode'] == "0")
			{
			    alert("Top-up successfull, Current Balance is "+res.NewBalance);
			    
			}else {
			    if(res.Response['ResponseCode'] == "1"){
			        alert("No Top Up Done");
			    }else if(res.Response['ResponseCode'] == "515"){
			        alert("Invalid voucher PIN");
			    }else if(res.Response['ResponseCode'] == "516"){
			        alert("Voucher expired");
			    }else if(res.Response['ResponseCode'] == "517"){
			        alert("Service not available");
			    }else if(res.Response['ResponseCode'] == "520"){
			        alert("Charge card has been already used");
			    }else if(res.Response['ResponseCode'] == "521"){
			        alert("Charge card is not activated");
			    }else if(res.Response['ResponseCode'] == "557"){
			        alert("Topup Rejected (MPP Subscriber)");
			    }else if(res.Response['ResponseCode'] == "570"){
			        alert("Topup not Allowed for Ent Subscriber");
			    }else if(res.Response['ResponseCode'] == "1079"){
			        alert("Topup Failed. Contact Customer Care");
			    }else if(res.Response['ResponseCode'] == "1026"){
			        alert("Voucher already used");
			    }else{
			        alert("Invalid voucher PIN");
			    }
			}
		},
		error: function(xhr)
		{
			ldr.hide();
			//alert(xhr.statusText);
		}
	});

});


});
