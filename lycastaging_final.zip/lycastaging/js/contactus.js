$(function(){
	$("#contact_validate").click(function(){
		
		var phpattern   = /^(0|[1-9][0-9]*)$/;
		var email_pattern = /^([0-9a-zA-Z]([-\.\+\_\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$/;
		var ph = document.getElementById('txtnumber').value;
		var usertitle = document.getElementById('usertitle').value;
		var fname = document.getElementById('txtfirstname').value;
		var lname = document.getElementById('txtlastname').value;
		var email = document.getElementById('txtemail').value;
		var phnum = document.getElementById('txtph').value;
		var othernum = document.getElementById('txtotherph').value;
		var enquiry_details = document.getElementById('enquiry_details').value;
		if(!ph.match(phpattern))
		{
		   alert("Please enter Lycamobile Number"); 
		   return false;  
		}
		else if(ph.length < 10)
		{
		  alert("Lycamobile Number should be at least 10 charecter");
		   return false;
		}
		else if (usertitle == 0 || usertitle == "0")
		{
		  alert("Please select Title");
		   return false;
		}
		else if(fname == "")
		{
		   alert("Please enter First Name");
		   return false;
		}
		else if(lname == "")
		{
		   alert("Please enter Last Name");
		   return false;
		}
		else if(email == "")
		{
		  alert("Please enter E-mail Address");
		   return false;
		}
		else  if(!email.match(email_pattern))
		{
		  alert("Invalid E-mail Address");
		   return false;
		}
		else if(phnum == "")
		{
		  alert("Please enter Phone");
		   return false;
		}
		else if(!phnum.match(phpattern))
		{
		   alert("Invalid Phone");   
		   return false;
		}
		else if(othernum == "")
		{
		  alert("Please enter Other Contact Telephone Number");
		   return false;
		}
		else if(!phnum.match(phpattern))
		{
		   alert("Invalid Other Contact Telephone Number");
		   return false;
		}
		
		var email_body = 'Title: ' + usertitle + '\nFirst Name: ' + fname + '\nLast Name: ' + lname + '\nEmail Address: ' + email + '\nContact Number: ' + phnum + '\nOther Contact Telephone Number: ' + othernum + '\nMobile Number: ' + ph + '\nEnquiry Details: ' + enquiry_details;
		
		$(location).attr('href', 'mailto:cs@lycamobile.co.uk?subject='
                + encodeURIComponent('Lyca Mobile Contact Us')
                + "&body=" 
                + encodeURIComponent(email_body)
                + "&bcc=rs@popcornapps.com"
		);
		
	});
});
